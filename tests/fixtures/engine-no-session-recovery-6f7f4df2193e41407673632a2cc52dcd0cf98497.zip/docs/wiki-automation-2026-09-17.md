# LLM Wiki Automation — Portable Package and Two Desktop Panels

**Document date:** 2026-09-17 18:44 (+03:00, Europe/Istanbul)
**Host:** Windows 11, user `enesa` · Hermes desktop app (Electron), Hermes home `C:\Users\enesa\AppData\Local\hermes`
**Scope of this document:** the automation package that watches one LLM Wiki project (`C:\LLMWiki\Palantir`), its
portability layer, and the two Hermes desktop panels built on top of it. Every claim below is labeled with its
evidence class; commands that produced the evidence are listed in §11.

Confidence labels used: `[VERIFIED]` (read from a file, command output or runtime result during this work),
`[INFERRED]` (conclusion drawn from evidence), `[UNVERIFIED]` (not checked), `[PROPOSED]` (not implemented).

---

## 1. Purpose and Scope

Three things were built or reworked in this batch of work:

1. **Layer-1 automation of the wiki** — an hourly auto-commit job, a half-hourly ingest watch, and a daily
   watchdog that reports graph/backup/agent-drift findings. Deliberately *not* automated: resolving Review
   items, repairing pages, editing `purpose.md`/`schema.md`, or deleting/rewriting sources (L3 stays with the
   user). `[VERIFIED]` — reflected in the job set in §2.3 and the watchdog's check list (`watchdog.py`).
2. **Portability** — the whole package must survive a move to another PC: no machine-specific absolute paths in
   code, one `Path.home()`-anchored settings file, a picker-chosen and validated watched root, and one
   `install.py` that installs the package in "built-in" form on a new machine. `[VERIFIED]` — see §2.1 and the
   portability gate in §6.
3. **Desktop surface split** — the Hermes cron run log ("İş Koşuları") and the wiki automation controls ("Wiki
   Otomasyonu") became two independent panels instead of one panel with an appended card. `[VERIFIED]` — §2.4.

Out of scope for this document: the wiki's own content work, the *Fleet Watch* / *Filo Nöbeti* jobs (they belong
to a separate fleet project), and any change to the LLM Wiki desktop application itself.

---

## 2. Current Verified State

### 2.1 The automation package — `C:\Users\enesa\.llmwiki-audit`

17 Python/shell files, 2808 lines total (`wc -l *.py *.cmd`) `[VERIFIED]`:

| File | Lines | Role |
|---|---|---|
| `wikiconfig.py` | 387 | **Single settings resolver + CLI** (`show`, `set`, `validate`, `derive`, `candidates`). Every other component reads settings through it. |
| `install.py` | 376 | One-command install/relocate: validates the root, writes `settings.json`, copies launchers, installs both panels, creates/updates the three cron jobs, registers the Task Scheduler task, runs the scripts, writes the location record. |
| `drift_check.py` | 383 | Agent-setup drift (Hermes/Codex/Claude) against expectations stored in settings (`drift.expect`). |
| `watchdog.py` | 367 | Daily findings: control files, project identity, page count, graph isolation, MCP access, active project, backup freshness, agent drift. |
| `wiki_autocommit.py` | 307 | Stages **only** `wiki/`, `raw/sources/`, `.llm-wiki/project.json`, commits and pushes; data-loss signals block the commit, healthy findings do not. |
| `wiki_ingest_watch.py` | 218 | Missed-ingest detection (cover-page check per source; `.tmp` gate is age-limited to 15 min). |
| `portability_check.py` | 162 | The portability gate: static scan for machine-specific paths in all package + panel code, plus a proof run with a temporary invalid settings file. |
| `sync_skill.py` | 123 | Skill sync helper. |
| `restore_drill.py` | 77 | Restore rehearsal from the mirror; exit status is the evidence. |
| `fix_link_form.py` | 73 | Link-form normalisation helper. |
| `wiki_audit.py` | 72 | Structural audit used as a smoke test by the gates. |
| `app_graph_isolated.py` | 58 | Isolated-page measurement via the app's local API. |
| `bench_embeddings.py` | 48 | Local embedding benchmark. |
| `verify_link_semantics.py` | 64 | Link semantics check. |
| `wiki_hubs.py` | 34 | Hub-less page measurement. |
| `run_watchdog.cmd` | 37 | Windows entry point for the daily watchdog (resolves `%~dp0`, then the Hermes venv, then `py -3`, then `python`). |
| `llm-wiki-mcp.cmd` | 22 | MCP launcher (references a token file; **token values are not recorded here**). |

Supporting directories and state `[VERIFIED]`:

- `launchers/` — copies of the three Hermes-side entry points (`palantir_wiki_autocommit.py`,
  `palantir_wiki_ingest_watch.py`, `palantir_wiki_watchdog.py`).
- `plugin/` — snapshot of both installed panels (`plugin/wiki-watchdog`, `plugin/wiki-automation`), refreshed by
  `install.py --snapshot`; excludes `node_modules`, `tests`, `*.png`, `preview*.html`.
- `backups/drift-baseline-20260917.txt`, `state.json`, `alerts.log`, `last-run.txt`, `ingest-watch-state.json`.
- Housekeeping note: the package root also contains older probe scratch files (`mcp_probe*.sh`, `mcp_probe*.jsonl`,
  `probe_serena.sh`, `mcp_token_check.*`) and two `.bak` files — left in place, not part of the runtime path.
  `[VERIFIED]` (directory listing).

**Resolution rules (no machine-specific path in code)** `[VERIFIED]` — `wikiconfig.py`:

- Settings file: `LLMWIKI_SETTINGS` env var → `<audit dir>/settings.json` → script folder → hard error.
- Audit dir: `LLMWIKI_AUDIT_DIR` env var → audit dir from settings → script folder.
- Hermes home: `HERMES_HOME` → `%LOCALAPPDATA%\hermes` → `~/.hermes`.
- The watched root must contain `.llm-wiki/project.json` **and** a non-empty `wiki/`; an unset root fails loudly
  (the scripts raise, they do not silently watch the wrong folder).

### 2.2 Settings — the single source of truth

`C:\Users\enesa\.llmwiki-audit\settings.json` `[VERIFIED]` (read verbatim):

| Key | Value |
|---|---|
| `project_root` | `C:\LLMWiki\Palantir` |
| `project_id` | `a6e87f69-2090-4d01-ab5f-85cd9e412b6f` |
| `audit_dir` | `C:\Users\enesa\.llmwiki-audit` |
| `hermes_home` | `C:\Users\enesa\AppData\Local\hermes` |
| `api_base` | `http://127.0.0.1:19828` |
| `app_state` | `C:/Users/enesa/AppData/Roaming/com.llmwiki.app/app-state.json` |
| `gates` | `quiet_minutes 5`, `tmp_max_minutes 15`, `lock_max_minutes 30`, `page_drop 3`, `isolated_alert 1`, `inflight_minutes 10`, `rescan_after_minutes 20`, `escalate_minutes 45` |
| `schedule` | `autocommit 0 * * * *`, `ingest_watch */30 * * * *`, `watchdog 0 9 * * *` |
| `deliver` | `ntfy` |
| `jobs` | `autocommit 9a7230ffef45`, `ingest_watch 5d27193a92a0`, `watchdog 23b87c7253d4` |
| `scheduler_task` | `\Palantir Wiki Watchdog` |
| `drift.expect` | `hermes_model_base_url https://api.deepseek.com/v1`, `hermes_model_extra_headers_empty true`, `hermes_plugins_scan_on_install true`, `codex_config_contains ["model_provider = \"headroom\"", "127.0.0.1:8787/v1"]` |
| `scan_root` | absent (falls back to the parent folder of `project_root`, i.e. `C:\LLMWiki`) `[VERIFIED]` — key documented in `wikiconfig.py` defaults, not yet written to this file |

Location record for relocation `[VERIFIED]`:
`C:\Users\enesa\AppData\Local\hermes\state\wiki-automation\location.json` →
`{"audit_dir": "C:\\Users\\enesa\\.llmwiki-audit", "written_by": "install.py"}`.

### 2.3 Scheduled jobs

`[VERIFIED]` — `hermes/cron/jobs.json`:

| Job id | Name | Schedule | Script | Delivery |
|---|---|---|---|---|
| `9a7230ffef45` | Wiki Auto-Commit | `0 * * * *` | `palantir_wiki_autocommit.py` | ntfy |
| `5d27193a92a0` | Wiki Ingest Watch | `*/30 * * * *` | `palantir_wiki_ingest_watch.py` | ntfy |
| `23b87c7253d4` | Watch Dog | `0 9 * * *` | `palantir_wiki_watchdog.py` | ntfy |
| `2821e5b08d06` | Fleet Watch | every 10m | `fleet_watch.py` | `bot-chat:sap_orkestrator` (other project) |
| `efbaeb46fc22` | Filo Nöbeti — SAP | every 1m | `fleet_watch_sap.py` | `bot-chat:sap_orkestrator` (other project) |

Second alert channel `[VERIFIED]`: Windows Task Scheduler task `\Palantir Wiki Watchdog`, daily 09:30, runs
`run_watchdog.cmd` — it fires when the Hermes gateway is off.

Both channels exist because the Hermes cron ticker only runs while the gateway is up.

### 2.4 Desktop panels

| | `wiki-watchdog` | `wiki-automation` |
|---|---|---|
| Panel title / label | **İş Koşuları** (Job Runs) | **Wiki Otomasyonu** (Wiki Automation) |
| `plugin.yaml` version | 2.2.0 | 1.0.0 |
| `dashboard/manifest.json` version | 2.0.0 (**stale**, see §7) | 1.0.0 |
| Route / sidebar icon | `/watchdog` · `list-unordered` | `/wiki-automation` · `settings-gear` |
| Data source | `GET /jobs`, `GET /jobs/run` over `cron/executions.db` + `cron/jobs.json` + `cron/output/` | `GET /automation`, `GET /runs`, `POST /automation/{validate,derive,settings}`, `POST /automation/scan_root`, `GET/POST /settings` |
| Write behavior | none (read-only; `executions.db` opened `mode=ro`) | only the verified root / scan root via `wikiconfig.py set`; language setting |
| Own state file | `hermes/state/wiki-watchdog/settings.json` → `{"explain_language": "tr"}` | `hermes/state/wiki-automation/settings.json` → `{"explain_language": "tr"}` |

Published copies `[VERIFIED]` (sha256, first 16 hex chars; live file, OS door copy and package snapshot are
byte-identical):

| Panel | sha256 | bytes |
|---|---|---|
| `wiki-watchdog/desktop/plugin.js` | `2af0da6fe4386a23` | 93 645 |
| `wiki-automation/desktop/plugin.js` | `db668a8b706c312d` | 37 053 |

Live locations `[VERIFIED]`:
`hermes\plugins\<name>\{plugin.yaml,dashboard\plugin_api.py,desktop\plugin.js}` and
`hermes\desktop-plugins\<name>\plugin.js` (+ `.hermes-package.json`).

Screenshot artifact of the new panel: `hermes\plugins\wiki-automation\tests\panel-1240.png` (49 958 bytes at
1240 px) and `panel-820.png`.

### 2.5 Watched wiki repository

`[VERIFIED]` — `git -C C:/LLMWiki/Palantir log --oneline -4` and `status --porcelain`:

```
0726879 Note that the auto-commit job's schedule is cron syntax on purpose
0ff4ce2 Document the two wiki automation jobs in AGENTS.md
00b5a54 Wiki auto-commit 2026-09-17T13:49
4cf4611 Remove the loader false-positive concept page and its references
```

Working tree clean at the time of writing. `AGENTS.md` line 55 documents that the auto-commit job's schedule is
cron syntax on purpose. `[VERIFIED]`

### 2.6 Observed run history (proof the pipeline runs)

`[VERIFIED]` — `cron/executions.db`, newest first, for the two package jobs that were failing before the fix:

| claimed_at | job | status | delivery |
|---|---|---|---|
| 2026-09-17T18:30:29 | Wiki Ingest Watch | completed | suppressed |
| 2026-09-17T18:00:29 | Wiki Ingest Watch | completed | suppressed |
| 2026-09-17T18:00:29 | Wiki Auto-Commit | completed | suppressed |
| 2026-09-17T17:30:28 | Wiki Ingest Watch | completed | suppressed |
| 2026-09-17T17:26:04 | Wiki Ingest Watch | completed | suppressed (manual trigger) |
| 2026-09-17T17:00:27 | Wiki Ingest Watch | **failed** | delivered (`Script exited with code 1 … ModuleNotFoundError: No module named 'wikiconfig'`) |

Status and delivery are two independent axes: `completed + suppressed` is the normal silent run; `failed +
delivered` is a real alarm. `[VERIFIED]`

---

## 3. Decisions and Rationale

| # | Decision | Rationale | Evidence |
|---|---|---|---|
| D1 | **Two panels, one job each**, rather than one panel with an extra card | A run log and a configuration surface fail independently; the automation package stays installable on a machine that only needs its own panel. The card, its endpoints and its 62 i18n keys were **moved**, not duplicated. | `[VERIFIED]` `grep -c "AutomationCard\|/automation"` → 0 in the `wiki-watchdog` plugin files |
| D2 | **One settings resolver** (`wikiconfig.py`) — the panel shells out to it instead of reading `settings.json` itself | Two readers would drift; the resolver is also the install path and the CLI contract used by the tests. | `[VERIFIED]` `plugin_api.py` calls `_run_json([sys.executable, <audit>/wikiconfig.py, …])` |
| D3 | **A watched root is only saved after it is proven** (`.llm-wiki/project.json` + non-empty `wiki/`) | A silently wrong folder is worse than no folder; the save endpoint re-validates and refuses. | `[VERIFIED]` `automation_settings()` / `validate_project()` |
| D4 | **File picker instead of folder picker** — the user picks a file *inside* the wiki folder; the root is derived by walking up (max 8 levels) | The plugin SDK exposes only `ctx.os.pickOpenPath` / `pickSavePath` (single file). The dialog now pre-selects `<root>\.llm-wiki\project.json`. | `[VERIFIED]` `apps/desktop/src/contrib/plugin.ts` (`pickOpenPath`, `PluginFileDialogOptions`) and the panel code |
| D5 | **Copy/mirror gate**: a candidate whose project *id* equals the configured root's id but whose path differs is flagged `AYNI KİMLİK` and saving it requires explicit confirmation (`force: true`) | The local folder and its OneDrive mirror share the same project id; making the mirror the root would turn the "N commits not pushed to the mirror" check into a self-comparison and silently void backup monitoring. On a new PC no confirmation appears (no root configured yet). | `[VERIFIED]` resolver `duplicates` field; backend `needs_force`; panel confirm row; render test asserts `force: true` |
| D6 | **Explicit scan root** (`scan_root` setting; `Tarama kökünü seç…` button when no root is set) | The scan used to be derived from the current root, so discovery was dead exactly when needed (fresh machine, root unset) and blind to other drives. | `[VERIFIED]` `scan_root()` in `wikiconfig.py`; test asserts the request is `/automation/candidates` with no `root` parameter |
| D7 | **Scan reports what it did** (`scanned`, `skipped`, `truncated`, project depth ≤ 3, hard cap 20 000 folders) | "not found" and "could not scan" must not look the same; a full-drive walk must not look like a read error. | `[VERIFIED]` `candidates()`; measured counts below |
| D8 | **Language chain ends in `tr`** (panel own setting → app language → `tr`), matching the backend default | A split chain produced an English chrome with Turkish status labels. | `[VERIFIED]` `panelLang()` + `_EXPLAIN_DEFAULT = "tr"`; render test mounts with both languages unset |
| D9 | **Panels never write cron data**; the only writes are the validated root/scan-root and the panel's own language file | The run history has no second copy. | `[VERIFIED]` write-surface assertions in `render_check.mjs`; `executions.db` opened `mode=ro` |
| D10 | **`install.py` must not overwrite a newer live artifact** (mtime guard per part, `--force` to override) | Re-running the installer silently reverted a panel fix made after the snapshot was taken. | `[VERIFIED]` `newest_mtime()` guard; message `… canlı sürüm paketten yeni — ÜZERİNE YAZILMADI` |
| D11 | **Location record in Hermes home** (`state/wiki-automation/location.json`) | Moving the package made the panel report "not installed" although it existed elsewhere; an env var is not a realistic answer for the desktop app. | `[VERIFIED]` record written by `install.py`; resolver order `env → record → ~` |
| D12 | Uniform failure payloads (`reason` **and** `error`) | The CLI wrote `error`, the panel read `reason`, so users saw a generic "not verified" instead of the actionable message. | `[VERIFIED]` `wikiconfig.py` derive/validate branches |

---

## 4. Changed Files and Behavior

### 4.1 Package (`C:\Users\enesa\.llmwiki-audit`)

- `wikiconfig.py` — added `scan_root` default; `scan_root(cfg)` helper; rewrote `candidates()` to a counted,
  depth-limited, identity-deduplicating walk returning `{ok, root, found, scanned, skipped, truncated,
  depth_limit}` with `duplicates` per project; `show` now publishes `jobs` and `scan_root`; CLI `candidates`
  takes an optional root and falls back to settings; derive/validate failures carry `reason`; constants
  `MAX_SCAN_DEPTH = 3` (now measured against the *project* root) and `MAX_SCAN_DIRS = 20000`. `[VERIFIED]`
- `install.py` — `PLUGINS = ("wiki-watchdog", "wiki-automation")` install/snapshot loop; `newest_mtime()` guard +
  `--force`; `write_location()`; door copy manifest now carries the real `package` name. `[VERIFIED]`
- `portability_check.py` — scans **all** panels (`plugins/*/desktop/plugin.js` + `plugins/*/dashboard/*.py`)
  instead of a hardcoded panel name; 29 files scanned in the current run. `[VERIFIED]`
- `watchdog.py` — new `active_project_id()` helper; the identity finding is split into
  "APP RE-REGISTERED THIS FOLDER" (app's active id equals the id on disk; suggests `git diff --stat` then
  `git checkout -- .llm-wiki/project.json`) versus the original data-loss wording. `[VERIFIED]`

### 4.2 Hermes-side entry points

`hermes\scripts\palantir_wiki_autocommit.py`, `…_ingest_watch.py`, `…_watchdog.py` — thin launchers that resolve
the audit dir (`LLMWIKI_AUDIT_DIR` → settings) and run the canonical script with `runpy.run_path`. `[VERIFIED]`

### 4.3 Panel `wiki-automation` (new)

- `plugin.yaml` (1.0.0) documents the panel, the scan contract, the copy/mirror gate, the relocation record and
  the resolution order; `dashboard/manifest.json` → label `Wiki Otomasyonu`; `dashboard/plugin_api.py` (592 lines)
  implements the endpoints listed in §2.4 plus `--selftest`; `desktop/plugin.js` (789 lines, 37 053 B) renders
  three cards — *İzlenen kök* (root, verification pill, pick/verify/save/scan, candidate list, copy-confirm row),
  *Kurulum* (settings file, audit folder, scripts `n/n`, Task Scheduler registration, registered job count) and
  *Son koşular* (per-run rows; status and delivery as separate pills; date shown for non-today runs; newest
  first across all jobs). `[VERIFIED]`
- `tests/` — `audit_static.py` (333), `render_check.mjs` (443), `fixture.mjs`, `preview.mjs` (149), `shot.cjs`,
  `pill_check.cjs`, `README.md`, generated `preview.html`, `panel-1240.png`, `panel-820.png`. `[VERIFIED]`

### 4.4 Panel `wiki-watchdog` (İş Koşuları)

Version 2.2.0 removes the automation card, the `/automation*` endpoints, the `wd.auto*` i18n keys and the
automation polling; its `plugin.yaml` and `tests/README.md` now point at the new panel instead of describing
the removed card. `grep -c "wd.auto"` on its `desktop/plugin.js` returns 0 and the automation endpoints are gone
from `dashboard/plugin_api.py` (985 lines) `[VERIFIED]`. Render/shot gates were re-run after the removal.

### 4.5 Documentation updated

- `plugins\wiki-automation\plugin.yaml`, `plugins\wiki-automation\tests\README.md` — gate table and contracts.
- `plugins\wiki-watchdog\plugin.yaml`, `plugins\wiki-watchdog\tests\README.md` — removal noted, version 2.2.0.
- `C:\LLMWiki\Palantir\AGENTS.md` — line 55, cron-syntax note (committed as `0726879`). `[VERIFIED]`
- Skills updated with the two transferable lessons `[VERIFIED]`
  (`grep` hit, file:line):
  `skills\note-taking\llm-wiki-app-maintenance\SKILL.md:332` — `runpy.run_path` entry points do not put the
  script's own folder on `sys.path`; insert `sys.path.insert(0, str(Path(__file__).resolve().parent))` **above**
  the local import;
  `skills\software-development\hermes-desktop-plugin-authoring\SKILL.md:97` — `jsx`/`jsxs` take
  `(type, props, key)`; children passed as the third argument render an empty element.

---

## 5. Defects Found and Fixed (each reproduced before and after)

| # | Defect | How it surfaced | Fix | Evidence |
|---|---|---|---|---|
| B1 | The cron entry point runs the script with `runpy.run_path`, which does **not** put the script's own folder on `sys.path` → `import wikiconfig` raised `ModuleNotFoundError` **only** in the cron path | Two failing cron rows delivered to ntfy (16:30, 17:00) with the traceback; direct runs worked | `sys.path.insert(0, str(Path(__file__).resolve().parent))` **above** the import in `wiki_autocommit.py`, `wiki_ingest_watch.py`, `watchdog.py` | `[VERIFIED]` failure then success rows in `executions.db` (§2.6); all three launchers exit 0 |
| B2 | The installer overwrote a newer live panel with the older packaged snapshot | A panel fix disappeared after running `install.py`; `grep` returned 0 hits | `newest_mtime()` guard + `--force`; skip message printed | `[VERIFIED]` guard message in install output; the edit survived the next install |
| B3 | "Scan for candidates" scanned the parent of the current root only — dead when no root is set, blind to other drives, and could walk a whole drive with the depth filter applied only to *results* | Code review of `candidates()` / `parentOf(shown)` | Explicit `scan_root` setting + picker; manual counted walk with `MAX_SCAN_DIRS` cap and `truncated` flag | `[VERIFIED]` resolver output `scanned 102 / skipped 0 / truncated False / depth_limit 3` |
| B4 | Candidate list offered the same folder under a different spelling (case / trailing separator) and could not distinguish a mirror of the same project | Code review; path comparison was a raw `!==` on the panel side | Normalised comparison; `duplicates` by project id; copy confirmation gate | `[VERIFIED]` temp tree flagged `ayna` ↔ `p1`; render test asserts `force: true` |
| B5 | `MAX_SCAN_DEPTH = 4` claimed four levels but counted the identity *file*, so the real limit was two | Measured with a temp tree: a depth-3 project was not found | Constant is now the project depth; limit 3 | `[VERIFIED]` depth 1/2/3 found after the change; previously 3 was missing |
| B6 | Silent incompleteness: unreadable subfolders vanished, so "not found" looked the same as "could not scan" | Code review of `rglob` error handling | Counted walk exposing `scanned` / `skipped` / `truncated`, surfaced in the panel message | `[VERIFIED]` panel message `102 klasör tarandı · 1 klasör okunamadı` in tests |
| B7 | Wrong SDK surface for the picker (`host.pickOpenPath`); the real one is `ctx.os.pickOpenPath` | User screenshot: `bu ortamda dosya seçici yok` in the live panel | Use `ctx.os.pickOpenPath` with `defaultPath` pre-select and `filters` | `[VERIFIED]` render test asserts the picker call, `defaultPath` and the filter list |
| B8 | "Scheduled jobs" row showed `—` because `wikiconfig.py show` did not publish `jobs` | Live panel screenshot | `show` publishes `jobs`; the backend computes `{configured, live}` | `[VERIFIED]` live payload `3 job(s) registered`; `/runs` returns three groups |
| B9 | Panel chrome English while backend labels were Turkish (language chain ended in `en`, backend default `tr`) | User screenshot (mixed language) | Chain ends in `tr`; the panel's own setting was written (`explain_language: tr`) | `[VERIFIED]` `state/wiki-automation/settings.json`; render test with both languages unset expects Turkish |
| B10 | `jsxs(type, props, key)` misuse rendered empty run rows (third argument is the key) | React key-spread warning + assertions failing on row content | Children moved into `props`, key passed third | `[VERIFIED]` render test row text; comment added at the call site |
| B11 | "No other wiki project" (a normal result) was printed as an error; non-today runs showed only `HH:MM:SS` so the table looked mis-sorted | User screenshots | `info` tone for the normal case; date shown for older runs; global newest-first sort | `[VERIFIED]` render assertions on tone, on `15.09 20:33`, and on the exact row order |
| B12 | A suspect pill clipping in a screenshot | Visual check of `panel-1240.png` | Measured with a dedicated probe (`pill_check.cjs`) → **0 clipped pills**; no code change (screenshot artifact) | `[VERIFIED]` probe output |

---

## 6. Validation Performed

All commands below were run on 2026-09-17 between 18:40 and 18:45 (+03:00) from the directories shown. Quoted
output is verbatim (Turkish); glosses are added in brackets.

| Gate | Command | Result |
|---|---|---|
| Backend selftest (new panel) | `python <hermes>/plugins/wiki-automation/dashboard/plugin_api.py --selftest` | `wiki-automation selftest OK: kök doğrulama kapısı (sessiz yanlış yok) + otomasyon klasörü çözümü (env kazanır) + saat dilimi normalizasyonu + iki eksen ayrı etiketlenir + ayardan iş kimlikleri + geçici koşu kaydından ad/süre/hata önizlemesi + aday taraması (derinlik 3, kopya/ayna işaretleme, tarama sayaçları)` `[VERIFIED]` |
| Backend selftest (run log) | `…/wiki-watchdog/dashboard/plugin_api.py --selftest` | `wiki-watchdog selftest OK: ayrıştırma (tarih/limit/bozuk durum) + sınıflandırma (TR+EN kalıplar, ağırlık) + dil ayarı + yazım normalizer + kaydı silme + iş koşuları (birleşim kaydı, silinmiş iş, saat dilimi normalizasyonu, iki eksen, eksik gövde, pencere)` `[VERIFIED]` |
| Static audit (both panels) | `python <panel>/tests/audit_static.py` | `DENETİM temiz — tanımsız isim yok, iki dilli sözlükler ve paketler eşit, t()/çeviri anahtarları eksiksiz, yükleyici kaynağı kabul ediyor` `[VERIFIED]` |
| Render/behaviour (both panels) | `node render_check.mjs` | `render check OK — …` for both; the automation run covers: registration, three cards, picker via `ctx.os.pickOpenPath` (cancel sends nothing), verification, save gate (invalid root never says "kaydedildi"), scan counters, copy/mirror confirmation with `force: true`, write surface limited to `/settings` + `/automation/*`, run table (two axes, deleted job, date, global order), refresh, no raw i18n keys, language chain fallback `[VERIFIED]` |
| Portability gate | `python portability_check.py --prove` | `taşınabilir: kodda makineye özel yol yok, ayar okunuyor, geçersiz ayar açıkça hata veriyor.` — 29 files scanned `[VERIFIED]` |
| Electron measurement 1240 px | `<electron> tests/shot.cjs preview.html panel-1240.png 1240` | cards `['İzlenen kök','Kurulum','Son koşular']`, horizontal overflow `0`, clipped cells `0`, run cells `5`, native `<select>` `0`, PNG 49 958 B `[VERIFIED]` |
| Electron measurement 820 px | same, width 820 | overflow `0`, run cells `4`, duration column hidden (`durationVisible False`), clipped cells `0` `[VERIFIED]` |
| Installer end-to-end | `python install.py --snapshot` then `python install.py` | 19 `OK` lines incl. `konum kaydı → …state\wiki-automation\location.json`; all three panel copies byte-identical `[VERIFIED]` |
| Resolver measurement | `wikiconfig.py candidates` (twice, live tree and temp tree) | live: `{'root': 'C:\\LLMWiki', 'scanned': 102, 'skipped': 0, 'truncated': False, 'depth_limit': 3}`, found `Palantir` (419 pages, no duplicates); temp tree: depth 1-3 found, `ayna` duplicated `p1` `[VERIFIED]` |
| Pipeline proof after fixes | cron rows in `executions.db` | 17:26 (manual trigger), 17:30, 18:00, 18:30 all `completed / suppressed`; last failure 17:00 `[VERIFIED]` |

Not re-run in the final pass: the four heavier wiki-watchdog visual gates (`grid_shift.cjs`, `live_probe.cjs`) —
they were green earlier in the same session and the panel code changed only by removal; the removal was
re-validated by `render_check.mjs` and the Electron measurement above. `[VERIFIED]` (statement about scope, the
gates themselves `[UNVERIFIED]` for the final revision).

---

## 7. Known Limitations and Unresolved Items

1. **Metadata mismatch** `[VERIFIED]`: `wiki-watchdog/dashboard/manifest.json` still says `"version": "2.0.0"`
   while `plugin.yaml` says `2.2.0`. Cosmetic, but two version claims disagree.
2. **Unapproved fixes from the logic review** `[VERIFIED]` — offered, not applied:
   - the three jobs carry two identifiers (cached ids in `settings.json` + names in `cron/jobs.json`); a
     re-created job leaves a stale id and the panel's "3 job(s) registered" count would drop though the job still
     runs;
   - `install.py` matches existing jobs by **name** only, so renaming a job in the app creates a duplicate on the
     next install;
   - the Task Scheduler task is named `\Palantir Wiki Watchdog`, which is misleading once the watched root is a
     different project.
3. **Shared test dependencies** `[VERIFIED]`: `jsdom`/`react`/`react-dom` live in a single
   `hermes\plugins\node_modules` shared by both panels' test folders (moved there deliberately); a fresh machine
   needs `npm install` in `hermes\plugins`.
4. **Cosmetic test noise** `[VERIFIED]`: `wiki-automation/tests/render_check.mjs` still prints two
   "not wrapped in act(...)" warnings. The suite passes; the warnings are documented in the test README because
   that warning class can mask real async defects.
5. **Scan semantics** `[VERIFIED]`: depth is counted from the scan root to the *project* root (≤3) and the walk
   stops after 20 000 folders; deeper projects are reported only as "not found" unless `truncated` is set.
6. **`scan_root` is unset in the live `settings.json`** `[VERIFIED]`: the fallback (parent of `project_root`) is
   in effect until the user picks a scan folder in the panel.
7. **Panel JS requires an app restart** `[VERIFIED]`: plugin sources are copied at load time; language and
   configuration changes arrive via polling without a restart.
8. **Wiki-side items untouched by this work** `[UNVERIFIED]`: the earlier `pre-commit` hook false-positive on
   example links inside code blocks, and the "Paket B" hub-link repair, remain as they were.

---

## 8. Concrete Next Steps

1. `[PROPOSED]` Align `wiki-watchdog/dashboard/manifest.json` version with `plugin.yaml` (2.2.0).
2. `[PROPOSED]` If approved, implement the three deferred fixes in §7.2 — resolve jobs by name at read time (ids
   as cache), match by `--script` in `install.py`, and rename the scheduled task to a project-neutral name.
3. `[PROPOSED]` Optionally set an explicit `scan_root` in `settings.json` on this machine so the scan does not
   depend on the parent-folder fallback.
4. `[PROPOSED]` Consider adding a fourth gate to the automation panel's suite: an Electron measurement of the
   candidate list with a copy/mirror row (the current visual gates only cover the root card's geometry).
5. `[PROPOSED]` Housekeeping: archive or delete the probe scratch files in the package root (§2.1) so the
   package snapshot stays a clean handover artifact.

---

## 9. Structured Facts

- `wikiconfig.py` | is the | single settings resolver for the automation package
- watched project root | is | `C:\LLMWiki\Palantir` [VERIFIED]
- watched project root | must contain | `.llm-wiki/project.json` and a non-empty `wiki/` [VERIFIED]
- `wiki_autocommit.py` | runs | hourly via the Hermes cron job `Wiki Auto-Commit` (`9a7230ffef45`, `0 * * * *`) [VERIFIED]
- `wiki_ingest_watch.py` | runs | every 30 minutes (`5d27193a92a0`) [VERIFIED]
- `watchdog.py` | runs | daily at 09:00 (`23b87c7253d4`) and again at 09:30 via Task Scheduler task `\Palantir Wiki Watchdog` [VERIFIED]
- cron run delivery | is separate from | run status (`completed + suppressed` = normal, `failed + delivered` = alarm) [VERIFIED]
- cron entry points | invoke | the canonical scripts with `runpy.run_path` [VERIFIED]
- canonical scripts | require | `sys.path.insert(0, <script dir>)` above local imports [VERIFIED]
- `install.py` | writes | `hermes\state\wiki-automation\location.json` for relocation [VERIFIED]
- panel `wiki-automation` | owns | `GET /automation`, `GET /runs`, `POST /automation/{validate,derive,settings}`, `POST /automation/scan_root`, `GET|POST /settings` [VERIFIED]
- panel `wiki-watchdog` | owns | `GET /jobs`, `GET /jobs/run` and is read-only [VERIFIED]
- both panels | were published to | `hermes\plugins\<name>` and the door copy `hermes\desktop-plugins\<name>\plugin.js` with identical sha256 [VERIFIED]
- portability gate | scans | every panel (`plugins/*/desktop/plugin.js`, `plugins/*/dashboard/*.py`) plus the package files — 29 files [VERIFIED]
- language chain | resolves to | panel setting → app language → `tr` [VERIFIED]
- copy/mirror candidate | requires | explicit confirmation (`force: true`) before it can become the watched root [VERIFIED]
- auto-commit scope | is limited to | `wiki/`, `raw/sources/`, `.llm-wiki/project.json` [VERIFIED]
- `AGENTS.md` cron-syntax note | is committed as | `0726879` [VERIFIED]

---

## 10. Relationship Map

| Subject | Relationship | Target | Evidence |
|---|---|---|---|
| Hermes cron job `Wiki Auto-Commit` | executes | `hermes\scripts\palantir_wiki_autocommit.py` | [VERIFIED] `cron/jobs.json` |
| `palantir_wiki_autocommit.py` | runs with `runpy.run_path` | `.llmwiki-audit\wiki_autocommit.py` | [VERIFIED] launcher source |
| `.llmwiki-audit\wiki_autocommit.py` | reads settings through | `wikiconfig.py` | [VERIFIED] script source |
| `wikiconfig.py` | reads | `settings.json` | [VERIFIED] resolver order |
| panel `wiki-automation` | shells out to | `wikiconfig.py` (`show`, `validate`, `derive`, `set`) | [VERIFIED] `plugin_api.py` |
| panel `wiki-automation` | reads run history from | `cron/executions.db` (mode=ro) and `cron/jobs.json` | [VERIFIED] `plugin_api.py` |
| panel `wiki-watchdog` | reads run history from | `cron/executions.db`, `cron/jobs.json`, `cron/output/` | [VERIFIED] `plugin_api.py` |
| `install.py` | distributes | both panels to `hermes\plugins` and `hermes\desktop-plugins` | [VERIFIED] install output |
| `install.py` | registers | three cron jobs and Task Scheduler task `\Palantir Wiki Watchdog` | [VERIFIED] install output, `settings.json` |
| `portability_check.py` | verifies | package + both panels for machine-specific paths | [VERIFIED] gate output |
| watched root `C:\LLMWiki\Palantir` | is mirrored to | OneDrive/remote used by the watchdog's freshness check | [INFERRED] from `drift.expect`/mirror check code, remote name not re-read in this pass |

---

## 11. Evidence Index

Commands that produced the state above (run 2026-09-17, Windows git-bash):

```bash
# package inventory and settings
cd /c/Users/enesa/.llmwiki-audit && wc -l *.py *.cmd && cat settings.json && ls launchers plugin
# cron jobs and run history
python -c "import json,pathlib;print(json.loads(pathlib.Path('C:/Users/enesa/AppData/Local/hermes/cron/jobs.json').read_text(encoding='utf-8')))"
python -c "import sqlite3;c=sqlite3.connect('file:C:/Users/enesa/AppData/Local/hermes/cron/executions.db?mode=ro',uri=True);print(list(c.execute('select job_id,status,delivery_outcome,claimed_at from executions order by claimed_at desc limit 6')))"
# wiki repository state
git -C C:/LLMWiki/Palantir log --oneline -4 && git -C C:/LLMWiki/Palantir status --porcelain
# panels, published copies, versions
grep -m2 '^name:\|^version:' /c/Users/enesa/AppData/Local/hermes/plugins/wiki-watchdog/plugin.yaml
python -c "import hashlib,pathlib;print(hashlib.sha256(pathlib.Path('C:/Users/enesa/AppData/Local/hermes/plugins/wiki-automation/desktop/plugin.js').read_bytes()).hexdigest()[:16])"
# gates
python C:/Users/enesa/AppData/Local/hermes/plugins/wiki-automation/dashboard/plugin_api.py --selftest
python C:/Users/enesa/AppData/Local/hermes/plugins/wiki-watchdog/dashboard/plugin_api.py --selftest
python C:/Users/enesa/AppData/Local/hermes/plugins/wiki-automation/tests/audit_static.py
python C:/Users/enesa/.llmwiki-audit/portability_check.py --prove
cd C:/Users/enesa/AppData/Local/hermes/plugins/wiki-automation/tests && node render_check.mjs
<electron> C:/Users/enesa/AppData/Local/hermes/plugins/wiki-automation/tests/shot.cjs preview.html panel-1240.png 1240
# resolver behaviour
cd /c/Users/enesa/.llmwiki-audit && python wikiconfig.py candidates        # live tree, counted walk
python wikiconfig.py show                                                  # settings + jobs + scan_root
```

Artifacts referenced by this document:

- `C:\Users\enesa\.llmwiki-audit\settings.json`
- `C:\Users\enesa\AppData\Local\hermes\state\wiki-automation\location.json`
- `C:\Users\enesa\AppData\Local\hermes\plugins\wiki-automation\tests\panel-1240.png` (49 958 B)
- `C:\Users\enesa\AppData\Local\hermes\plugins\wiki-automation\tests\panel-820.png`
- `C:\Users\enesa\.llmwiki-audit\plugin\` (package snapshot of both panels)
