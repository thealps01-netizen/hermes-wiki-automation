"""Shared containment checks for review and constrained drafting."""
from pathlib import Path
import re


class PathRefused(RuntimeError):
    pass


def checked_path(root: Path, relative: str) -> Path:
    if not isinstance(relative, str) or not relative or '\\' in relative or ':' in relative or '\0' in relative:
        raise PathRefused('Invalid relative path')
    parts = relative.split('/')
    if any(p in ('', '.', '..') or p.endswith(('.', ' ')) for p in parts):
        raise PathRefused('Path traversal or ambiguous spelling')
    root = Path(root)
    current = root
    for part in [None, *parts]:
        if part is not None:
            if current.is_dir():
                matches = [p.name for p in current.iterdir() if p.name.casefold() == part.casefold()]
                if matches and matches != [part]:
                    raise PathRefused('Path case mismatch or collision')
            current = current / part
        if current.is_symlink() or (hasattr(current, 'is_junction') and current.is_junction()):
            raise PathRefused('Linked path refused')
        if current.is_file() and current.stat().st_nlink > 1:
            raise PathRefused('Hard-linked input refused')
    try:
        current.resolve().relative_to(root.resolve())
    except ValueError as exc:
        raise PathRefused('Path escapes root') from exc
    return current


def identifier(value: str) -> str:
    if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]{0,127}', value):
        raise PathRefused('Invalid identifier')
    if value.endswith(('.', ' ')):
        raise PathRefused('Ambiguous identifier')
    return value
