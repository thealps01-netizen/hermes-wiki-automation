"""Draft submissions are data, immutable in the inbox, and never live writes."""
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


class DraftTests(unittest.TestCase):
    def test_read_and_submit_are_confined_to_bound_run(self):
        import draft_adapter
        with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as temp:
            root = Path(temp)
            wiki, inbox = root / 'wiki', root / 'data/inbox'
            (wiki / '.llm-wiki').mkdir(parents=True)
            (wiki / '.llm-wiki/project.json').write_text('{"id":"fixture"}')
            (wiki / 'raw/sources').mkdir(parents=True)
            (wiki / 'raw/evidence').mkdir(parents=True)
            run = inbox / 'fixture-run'
            (run / 'conversations').mkdir(parents=True)
            (run / 'run.json').write_text(json.dumps({'execution_id': 'execution', 'job_id': 'job', 'project_id': 'fixture'}))
            (run / 'conversations/session.md').write_text('Owner chose the fixture.\n')
            adapter = draft_adapter.DraftAdapter(wiki, inbox, 'fixture-run', 'execution', 'job')
            read = adapter.read('conversations/session.md', 0, 5)
            self.assertEqual(read['text'], 'Owner')
            self.assertTrue(read['truncated'])
            self.assertEqual(read['next_offset'], 5)
            for denied in ('../secrets', 'candidate.json', '../../wiki/raw/sources/test.md', 'run.json/../../../secret'):
                with self.subTest(path=denied), self.assertRaises(draft_adapter.DraftRefused):
                    adapter.read(denied)
            before = {str(p): p.read_bytes() for p in wiki.rglob('*') if p.is_file()}
            metadata = dict(kind='new', target='2026-10-06-fixture.md', summary='Fixture', why='Owner choice', evidence_ids=[])
            source = '# Fixture\n\n## Decisions\n\n**1. Fixture.**\nEvidence: none (owner-directed).\n'
            ref = adapter.submit('fixture', metadata, source)
            self.assertEqual(ref, 'fixture-run/fixture')
            self.assertEqual(adapter.submit('fixture', metadata, source), ref)
            with self.assertRaises(draft_adapter.DraftRefused):
                adapter.submit('fixture', metadata, source + '\nChanged after review')
            after = {str(p): p.read_bytes() for p in wiki.rglob('*') if p.is_file()}
            self.assertEqual(before, after)
            self.assertFalse((run / 'candidates/fixture/applied.json').exists())
            with self.assertRaises(draft_adapter.DraftRefused):
                draft_adapter.DraftAdapter(wiki, inbox, 'fixture-run', 'different-execution', 'job')


if __name__ == '__main__':
    unittest.main()
