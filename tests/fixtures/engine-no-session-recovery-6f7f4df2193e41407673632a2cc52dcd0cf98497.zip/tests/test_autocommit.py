"""Safe staging and mirror verification use disposable local Git repositories only."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


class AutocommitTests(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory(dir=os.environ.get('TMPDIR'))
        self.addCleanup(tmp.cleanup)
        self.root = Path(tmp.name)
        self.wiki = self.root / 'wiki-project'
        self.wiki.mkdir()
        self.git('init', '-b', 'main')
        self.git('config', 'user.name', 'Isolated Fixture')
        self.git('config', 'user.email', 'fixture@example.invalid')
        for name in ('wiki', 'raw/sources', 'raw/evidence', '.llm-wiki'):
            (self.wiki / name).mkdir(parents=True, exist_ok=True)
        (self.wiki / '.llm-wiki/project.json').write_text('{"id":"fixture"}')
        (self.wiki / 'wiki/page.md').write_bytes(b'# Initial\n')
        (self.wiki / 'user.txt').write_bytes(b'Initial user work\n')
        self.git('add', '.')
        self.git('commit', '-m', 'Fixture baseline')
        self.audit = self.root / 'data'
        self.audit.mkdir()
        settings = self.root / 'settings.json'
        settings.write_bytes(json.dumps({'project_root': str(self.wiki), 'project_id': 'fixture', 'audit_dir': str(self.audit)}).encode())
        environment = patch.dict(os.environ, {'LLMWIKI_SETTINGS': str(settings)})
        environment.start()
        self.addCleanup(environment.stop)
        spec = importlib.util.spec_from_file_location('isolated_autocommit', Path(__file__).resolve().parents[1] / 'wiki_autocommit.py')
        self.module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.module)
        self.module.REMOTES = ()

    def git(self, *args):
        proc = subprocess.run(['git', '-C', str(self.wiki), *args], capture_output=True, timeout=15)
        if proc.returncode:
            raise AssertionError(proc.stderr.decode(errors='replace'))
        return proc.stdout

    def test_unrelated_partial_staging_preserved(self):
        (self.wiki / 'user.txt').write_bytes(b'Staged owner work\n')
        self.git('add', 'user.txt')
        (self.wiki / 'user.txt').write_bytes(b'Staged plus unstaged owner work\n')
        (self.wiki / 'wiki/page.md').write_bytes(b'# New page\n')
        index, head = self.git('diff', '--cached', '--binary'), self.git('rev-parse', 'HEAD')
        sha, message = self.module.app_commit(self.module.page_files())
        self.assertEqual(sha, '')
        self.assertIn('staged', message.lower())
        self.assertEqual(self.git('diff', '--cached', '--binary'), index)
        self.assertEqual(self.git('rev-parse', 'HEAD'), head)

    def test_failed_commit_cleans_only_unchanged_attempt_staging(self):
        (self.wiki / 'wiki/page.md').write_bytes(b'# New page\n')
        hooks = self.wiki / '.git/hooks'
        (hooks / 'pre-commit').write_bytes(b'#!/bin/sh\nexit 1\n')
        index = self.git('diff', '--cached', '--binary')
        sha, message = self.module.app_commit(self.module.page_files())
        self.assertEqual(sha, '')
        self.assertEqual(self.git('diff', '--cached', '--binary'), index)
        self.assertEqual((self.wiki / 'wiki/page.md').read_bytes(), b'# New page\n')

    def test_index_mutating_precommit_hook_is_refused_before_any_commit(self):
        (self.wiki / 'wiki/page.md').write_bytes(b'# New page\n')
        (self.wiki / '.git/hooks/pre-commit').write_bytes(
            b'#!/bin/sh\nprintf "Owner work\\n" > concurrent.txt\ngit add concurrent.txt\nexit 0\n')
        head = self.git('rev-parse', 'HEAD')
        sha, message = self.module.app_commit(self.module.page_files())
        self.assertEqual(sha, '', 'An index-mutating precommit hook ran during automatic commit')
        self.assertIn('hook', message.lower())
        self.assertEqual(self.git('rev-parse', 'HEAD'), head)
        self.assertEqual(self.git('diff', '--cached', '--name-only'), b'')
        self.assertFalse((self.wiki / 'concurrent.txt').exists())

    def test_failed_commit_preserves_concurrently_staged_owner_work(self):
        (self.wiki / 'wiki/page.md').write_bytes(b'# New page\n')
        original_git = self.module.git
        def concurrent_writer(*args):
            if args[0] == 'commit':
                (self.wiki / 'concurrent.txt').write_bytes(b'Owner work\n')
                self.git('add', 'concurrent.txt')
                return original_git('commit', '--invalid-fixture-option')
            return original_git(*args)
        with patch.object(self.module, 'git', side_effect=concurrent_writer):
            sha, message = self.module.app_commit(self.module.page_files())
        self.assertEqual(sha, '')
        self.assertIn('concurrent.txt', self.git('diff', '--cached', '--name-only').decode())
        self.assertIn('recovery', message.lower())

    def test_failed_push_is_retried_without_a_new_commit(self):
        remote = self.root / 'remote.git'
        subprocess.run(['git', 'init', '--bare', str(remote)], capture_output=True, check=True, timeout=15)
        self.git('remote', 'add', 'fixture', str(remote))
        self.git('push', 'fixture', 'HEAD:refs/heads/main')
        self.module.REMOTES = ('fixture',)
        (remote / 'hooks/pre-receive').write_bytes(b'#!/bin/sh\nexit 1\n')
        (self.wiki / 'wiki/page.md').write_bytes(b'# Committed, not pushed\n')
        self.git('add', 'wiki/page.md')
        self.git('commit', '-m', 'Fixture unpushed change')
        head = self.git('rev-parse', 'HEAD')
        result = self.module.retry_mirrors()
        self.assertEqual(result['fixture']['state'], 'behind')
        self.assertIn('error', result['fixture'])
        (remote / 'hooks/pre-receive').unlink()
        with patch.object(sys, 'argv', ['wiki_autocommit.py', '--force']):
            self.assertEqual(self.module.main(), 0)
        self.assertEqual(self.module.mirror_state()['fixture']['state'], 'fresh')
        self.assertEqual(self.git('rev-parse', 'HEAD'), head)

    def test_main_does_not_commit_while_an_application_holds_the_lock(self):
        from candidate_apply import operation_lock
        (self.wiki / 'wiki/page.md').write_bytes(b'# Still applying\n')
        head = self.git('rev-parse', 'HEAD')
        with operation_lock(self.audit), patch.object(sys, 'argv', ['wiki_autocommit.py', '--force']):
            self.assertEqual(self.module.main(), 1)
        self.assertEqual(self.git('rev-parse', 'HEAD'), head)
        self.assertEqual(self.git('diff', '--cached', '--name-only'), b'')

    def test_busy_apply_blocks_commit(self):
        from workflow_store import WorkflowStore
        with WorkflowStore(self.audit / 'workflow.sqlite') as store:
            store.record_operation({'operation_id': 'fixture-operation'})
            for old, new in (('collected', 'drafted'), ('drafted', 'awaiting_approval'), ('awaiting_approval', 'applying')):
                store.transition('fixture-operation', old, new)
        (self.wiki / 'wiki/page.md').write_bytes(b'# Changed\n')
        head = self.git('rev-parse', 'HEAD')
        sha, message = self.module.app_commit(self.module.page_files())
        self.assertEqual(sha, '')
        self.assertEqual(self.git('rev-parse', 'HEAD'), head)
        self.assertEqual(self.git('diff', '--cached', '--name-only'), b'')

    def test_unreachable_remote_is_unknown(self):
        self.git('remote', 'add', 'fixture', str(self.root / 'missing.git'))
        self.git('update-ref', 'refs/remotes/fixture/main', self.git('rev-parse', 'HEAD').decode().strip())
        self.module.REMOTES = ('fixture',)
        status = self.module.mirror_state()['fixture']
        self.assertIsInstance(status, dict, 'Mirror status trusts a tracking ref instead of checking actual remote')
        self.assertEqual(status['state'], 'unknown')


if __name__ == '__main__':
    unittest.main()
