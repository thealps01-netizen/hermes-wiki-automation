"""Independent process used for lock and abrupt-interruption tests."""
import json
import os
from pathlib import Path
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import candidate_apply
from candidate_apply import operation_lock, ApplyRefused
from workflow_store import WorkflowStore

try:
    if sys.argv[1] == 'apply':
        request = json.loads(Path(sys.argv[2]).read_bytes())
        count = [0]
        if len(sys.argv) == 4:
            def interrupt(point):
                if count[0] == int(sys.argv[3]):
                    os._exit(91)
                count[0] += 1
            candidate_apply._checkpoint = interrupt
        with WorkflowStore(Path(request['inbox']).parent / 'workflow.sqlite') as store:
            prepared = store.db.execute("SELECT id FROM operations WHERE json_extract(identity, '$.type')='candidate'").fetchall()
            if len(sys.argv) == 3 and prepared:
                result = candidate_apply.reconcile_operation(Path(request['wiki']), Path(request['inbox']), prepared[0][0], store)
            else:
                result = candidate_apply.apply_candidate(Path(request['wiki']), Path(request['inbox']),
                    'run/draft', request['snapshot'], request['approval'], store)
        print(json.dumps(result))
    else:
        with operation_lock(Path(sys.argv[2]), timeout=0):
            if sys.argv[1] == 'hold-lock':
                print('LOCKED', flush=True)
                time.sleep(60)
except ApplyRefused as exc:
    print(exc)
    raise SystemExit(2)
