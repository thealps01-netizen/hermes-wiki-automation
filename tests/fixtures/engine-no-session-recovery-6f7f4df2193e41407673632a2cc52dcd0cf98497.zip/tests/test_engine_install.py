"""Engine-owned setup uses isolated profile, code, project and data roots."""
import os
from pathlib import Path
import sys
import tempfile
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from unittest.mock import patch
import json
import install
import wikiconfig


class EngineInstallTests(unittest.TestCase):
    def prepared(self, home):
        import shutil
        root = Path(__file__).resolve().parents[1]
        code, wiki, data = home / 'code', home / 'wiki', home / 'data'
        code.mkdir()
        for source in [*root.glob('*.py'), *[root / name for name in ('jobs.json', 'panels.json', 'harvest_prompt.md')]]:
            shutil.copy2(source, code / source.name)
        shutil.copytree(root / 'launchers', code / 'launchers')
        (wiki / '.llm-wiki').mkdir(parents=True)
        (wiki / '.llm-wiki/project.json').write_text('{"id":"fixture"}')
        (wiki / 'wiki').mkdir()
        (wiki / 'wiki/index.md').write_text('# Fixture index\n')
        data.mkdir()
        cfg = {'project_root': str(wiki), 'project_id': 'fixture', 'hermes_home': str(home), 'audit_dir': str(data),
            'install_options': {'no_plugin': True, 'no_cron': True}}
        (data / 'settings.json').write_bytes(json.dumps(cfg).encode())
        return install.build_plan(cfg, home, code, data)

    def test_legacy_no_plugin_previews_location_without_panel_install(self):
        from contextlib import ExitStack
        with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as tmp:
            home = Path(tmp)
            plan = self.prepared(home)
            with ExitStack() as stack:
                stack.enter_context(patch.object(wikiconfig, 'load', return_value=plan['settings']))
                for name in ('copy_launchers', 'install_wiki_hooks'):
                    stack.enter_context(patch.object(install, name))
                stack.enter_context(patch.object(install, 'note'))
                stack.enter_context(patch.object(install, 'report', []))
                stack.enter_context(patch.object(install, 'verify', return_value=True))
                panel = stack.enter_context(patch.object(install, 'install_panels'))
                location = stack.enter_context(patch.object(install, 'write_location'))
                self.assertEqual(install.main(['install.py', '--project-root', plan['settings']['project_root'],
                    '--hermes-home', str(home), '--dry-run', '--no-plugin', '--no-cron']), 0)
                panel.assert_not_called()
                location.assert_called_once_with(home, True)

    def test_installation_journal_records_applied_projections_not_activation(self):
        from workflow_store import WorkflowStore
        with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as tmp:
            home = Path(tmp)
            plan = self.prepared(home)
            result = install.apply_plan(plan, plan['digest'])
            with WorkflowStore(home / 'state/wiki-automation/installation.sqlite', read_only=True) as store:
                operation = store.get_operation(plan['digest'])
                self.assertEqual(operation['state'], 'applied')
                self.assertEqual(operation['result'], result)
                self.assertEqual(result['state'], 'location_recorded')
                self.assertNotIn('activated', result)
            self.assertEqual(install.apply_plan(plan, plan['digest']), result)

    def test_unrelated_mapped_native_job_is_preserved_and_refused(self):
        from hermes_constants import set_hermes_home_override, reset_hermes_home_override
        from cron.jobs import use_cron_store, create_job, get_job, list_jobs
        with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as tmp:
            home = Path(tmp)
            previous = self.prepared(home)
            token = set_hermes_home_override(home)
            try:
                with use_cron_store(home):
                    unrelated = create_job(prompt='Owner unrelated task', schedule='0 6 * * *',
                        name='Owner task', no_agent=True, script='owner_task.py', paused=True)
                    cfg = {**previous['settings'], 'jobs': {'watchdog': unrelated['id']},
                        'install_options': {'no_plugin': True, 'no_cron': False}}
                    (Path(previous['audit_dir']) / 'settings.json').write_bytes(json.dumps(cfg).encode())
                    plan = install.build_plan(cfg, home, Path(previous['engine_dir']), Path(previous['audit_dir']))
                    with self.assertRaises(wikiconfig.ConfigError):
                        install.apply_plan(plan, plan['digest'])
                    self.assertEqual(get_job(unrelated['id']), unrelated)
                    self.assertEqual(len(list_jobs(include_disabled=True)), 1)
                    self.assertFalse((home / 'state/wiki-automation/location.json').exists())
            finally:
                reset_hermes_home_override(token)

    def test_invalid_location_never_resets_or_changes_retained_data(self):
        with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as tmp:
            home = Path(tmp)
            previous = self.prepared(home)
            location = home / 'state/wiki-automation/location.json'
            location.parent.mkdir(parents=True)
            for record in ({}, {'schema': 999, 'audit_dir': previous['audit_dir']},
                    {'schema': 2, 'engine_dir': previous['engine_dir'], 'audit_dir': 'relative-data'}):
                with self.subTest(record=record):
                    original = json.dumps(record).encode()
                    location.write_bytes(original)
                    with self.assertRaises(wikiconfig.ConfigError):
                        install.build_plan(previous['settings'], home, Path(previous['engine_dir']), Path(previous['audit_dir']))
                    self.assertEqual(location.read_bytes(), original)
            location.write_bytes(json.dumps(previous['location']).encode())
            other = home / 'other-data'
            with self.assertRaises(wikiconfig.ConfigError):
                install.build_plan(previous['settings'], home, Path(previous['engine_dir']), other)
            self.assertFalse(other.exists())

    def test_explicit_install_choices_override_saved_choices(self):
        with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as tmp:
            home = Path(tmp)
            previous = self.prepared(home)
            requested = {**previous['settings'], 'install_options': {'no_plugin': True, 'no_cron': False}}
            plan = install.build_plan(requested, home, Path(previous['engine_dir']), Path(previous['audit_dir']))
            self.assertIs(plan['settings']['install_options']['no_cron'], False)
            self.assertIs(plan['settings']['install_options']['no_plugin'], True)

    def test_real_install_projection_death_reuses_the_same_plan(self):
        import subprocess
        import sqlite3
        from contextlib import closing
        import candidate_apply
        with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as tmp:
            base = Path(tmp)
            trace = base / 'trace'
            trace.mkdir()
            plan = self.prepared(trace)
            points = []
            with patch.object(candidate_apply, '_checkpoint', side_effect=points.append):
                install.apply_plan(plan, plan['digest'])
            recovered = 0
            for number, point in enumerate(dict.fromkeys(points)):
                with self.subTest(checkpoint=point):
                    home = base / f'case-{number}'
                    home.mkdir()
                    pending = self.prepared(home)
                    artifact = home / 'install-plan.json'
                    artifact.write_bytes(json.dumps(pending).encode())
                    proc = subprocess.run([sys.executable, str(Path(__file__).with_name('install_apply_worker.py')),
                        str(artifact), point], capture_output=True, timeout=20)
                    self.assertEqual(proc.returncode, 91, proc.stderr.decode(errors='replace'))
                    result = install.apply_plan(pending, pending['digest'])
                    self.assertTrue(result['ok'])
                    location = json.loads((home / 'state/wiki-automation/location.json').read_bytes())
                    self.assertEqual(location['engine_dir'], pending['engine_dir'])
                    self.assertEqual(install.apply_plan(pending, pending['digest']), result)
                    with closing(sqlite3.connect(home / 'state/wiki-automation/installation.sqlite')) as database:
                        self.assertEqual(database.execute('SELECT COUNT(*) FROM operations').fetchone()[0], 1)
                    recovered += 1
            self.assertGreaterEqual(recovered, 6)
            print(f'INSTALL_PROJECTION_INTERRUPTION_CASES recovered={recovered}')

    def test_install_does_not_cross_an_unfinished_source_application(self):
        from workflow_store import WorkflowStore
        with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as tmp:
            home = Path(tmp)
            plan = self.prepared(home)
            with WorkflowStore(Path(plan['audit_dir']) / 'workflow.sqlite') as store:
                store.record_operation({'operation_id': 'busy-source', 'type': 'candidate'})
                for old, new in (('collected', 'drafted'), ('drafted', 'awaiting_approval'), ('awaiting_approval', 'applying')):
                    store.transition('busy-source', old, new)
            with self.assertRaises(wikiconfig.ConfigError):
                install.apply_plan(plan, plan['digest'])
            self.assertFalse((home / 'state/wiki-automation/location.json').exists())

    def test_resume_refuses_changed_project_identity(self):
        with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as tmp:
            home = Path(tmp)
            plan = self.prepared(home)
            install.apply_plan(plan, plan['digest'])
            identity = Path(plan['settings']['project_root']) / '.llm-wiki/project.json'
            identity.write_text('{"id":"different-owner-project"}')
            with self.assertRaises(wikiconfig.ConfigError):
                install.apply_plan(plan, plan['digest'])
            self.assertEqual(json.loads(identity.read_bytes())['id'], 'different-owner-project')

    def test_job_save_before_id_record_reconciles_without_duplicate_creation(self):
        import subprocess
        from hermes_constants import set_hermes_home_override, reset_hermes_home_override
        from cron.jobs import use_cron_store, list_jobs
        with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as tmp:
            base = Path(tmp)
            for role in ('autocommit', 'ingest_watch', 'watchdog', 'session_harvest'):
                with self.subTest(role=role):
                    home = base / role
                    home.mkdir()
                    initial = self.prepared(home)
                    cfg = {**initial['settings'], 'install_options': {'no_plugin': True, 'no_cron': False}}
                    (Path(initial['audit_dir']) / 'settings.json').write_bytes(json.dumps(cfg).encode())
                    plan = install.build_plan(cfg, home, Path(initial['engine_dir']), Path(initial['audit_dir']))
                    artifact = home / 'plan.json'
                    artifact.write_bytes(json.dumps(plan).encode())
                    process = subprocess.run([sys.executable, str(Path(__file__).with_name('install_apply_worker.py')),
                        str(artifact), 'after-create-job:' + role], capture_output=True, timeout=20)
                    self.assertEqual(process.returncode, 91, process.stderr.decode(errors='replace'))
                    install.apply_plan(plan, plan['digest'])
                    token = set_hermes_home_override(home)
                    try:
                        with use_cron_store(home):
                            jobs = list_jobs(include_disabled=True)
                            self.assertEqual(len(jobs), len(plan['job_definitions']))
                            self.assertEqual(len({job['id'] for job in jobs}), len(jobs))
                            self.assertTrue(all(job['enabled'] is False for job in jobs))
                    finally:
                        reset_hermes_home_override(token)
            print('INSTALL_NATIVE_JOB_INTERRUPTION_CASES recovered=4')

    def test_real_engine_only_cli_uses_selected_profile_and_records_location(self):
        import subprocess
        with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as tmp:
            home = Path(tmp)
            selected = self.prepared(home)
            script = Path(selected['engine_dir']) / 'install.py'
            command = [sys.executable, '-B', str(script), '--project-root', selected['settings']['project_root'],
                '--hermes-home', str(home), '--data-root', selected['audit_dir'], '--no-cron', '--no-plugin']
            preview = subprocess.run([*command, '--plan-json'], capture_output=True, text=True, timeout=20)
            self.assertEqual(preview.returncode, 0, preview.stdout + preview.stderr)
            plan = json.loads(preview.stdout)
            self.assertFalse((home / 'state/wiki-automation/location.json').exists())
            applied = subprocess.run([*command, '--expected-digest', plan['digest']], capture_output=True, text=True, timeout=20)
            self.assertEqual(applied.returncode, 0, applied.stdout + applied.stderr)
            self.assertTrue(json.loads(applied.stdout)['ok'])
            self.assertEqual(json.loads((home / 'state/wiki-automation/location.json').read_bytes())['audit_dir'], selected['audit_dir'])
            self.assertFalse((home / 'plugins').exists())

    def test_update_preserves_real_job_ids_and_custom_schedules(self):
        import shutil
        from hermes_constants import set_hermes_home_override, reset_hermes_home_override
        from cron.jobs import use_cron_store, list_jobs, update_job
        with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as tmp:
            home = Path(tmp)
            initial = self.prepared(home)
            cfg = {**initial['settings'], 'install_options': {'no_plugin': True, 'no_cron': False}}
            settings_file = Path(initial['audit_dir']) / 'settings.json'
            settings_file.write_bytes(json.dumps(cfg).encode())
            first = install.build_plan(cfg, home, Path(initial['engine_dir']), Path(initial['audit_dir']))
            install.apply_plan(first, first['digest'])
            token = set_hermes_home_override(home)
            try:
                with use_cron_store(home):
                    jobs = list_jobs(include_disabled=True)
                    watchdog = next(job for job in jobs if job['name'] == 'Watch Dog')
                    update_job(watchdog['id'], {'schedule': '20 7 * * *'})
                    original = {job['id']: job['schedule'] for job in list_jobs(include_disabled=True)}
                    new_code = home / 'code-updated'
                    shutil.copytree(Path(initial['engine_dir']), new_code)
                    cfg = json.loads(settings_file.read_bytes())
                    plan = install.build_plan(cfg, home, new_code, Path(initial['audit_dir']))
                    install.apply_plan(plan, plan['digest'])
                    self.assertEqual({job['id']: job['schedule'] for job in list_jobs(include_disabled=True)}, original)
                    self.assertEqual(json.loads(settings_file.read_bytes())['audit_dir'], initial['audit_dir'])
            finally:
                reset_hermes_home_override(token)

    def test_real_native_jobs_are_created_paused_and_not_duplicated(self):
        from hermes_constants import set_hermes_home_override, reset_hermes_home_override
        from cron.jobs import use_cron_store, list_jobs
        with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as tmp:
            home = Path(tmp)
            before = self.prepared(home)
            cfg = {**before['settings'], 'install_options': {'no_plugin': True, 'no_cron': False},
                'schedule': {'watchdog': '15 8 * * *'}}
            (Path(before['audit_dir']) / 'settings.json').write_bytes(json.dumps(cfg).encode())
            plan = install.build_plan(cfg, home, Path(before['engine_dir']), Path(before['audit_dir']))
            result = install.apply_plan(plan, plan['digest'])
            self.assertTrue(result['ok'])
            token = set_hermes_home_override(home)
            try:
                with use_cron_store(home):
                    jobs = list_jobs(include_disabled=True)
                    self.assertEqual(len(jobs), len(plan['job_definitions']))
                    self.assertTrue(all(job['enabled'] is False and job['state'] == 'paused' for job in jobs))
                    agent = [job for job in jobs if not job['no_agent']]
                    self.assertEqual(len(agent), 1)
                    self.assertEqual(set(agent[0]['enabled_toolsets']), {'wiki_draft', 'no_mcp'})
                    ids = {job['id'] for job in jobs}
                    self.assertEqual(install.apply_plan(plan, plan['digest']), result)
                    self.assertEqual({job['id'] for job in list_jobs(include_disabled=True)}, ids)
            finally:
                reset_hermes_home_override(token)

    def test_unowned_same_name_launcher_is_preserved_and_refused(self):
        with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as tmp:
            home = Path(tmp)
            plan = self.prepared(home)
            script = home / 'scripts/palantir_wiki_watchdog.py'
            script.parent.mkdir()
            original = b'Owner customized this launcher; it is not engine-owned\n'
            script.write_bytes(original)
            with self.assertRaises(wikiconfig.ConfigError):
                install.build_plan(plan['settings'], home, Path(plan['engine_dir']), Path(plan['audit_dir']))
            self.assertEqual(script.read_bytes(), original)
            self.assertFalse((home / 'state/wiki-automation/location.json').exists())

    def test_generated_launcher_reads_the_selected_code_and_data(self):
        import subprocess
        with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as tmp:
            home = Path(tmp)
            plan = self.prepared(home)
            install.apply_plan(plan, plan['digest'])
            launcher = home / 'scripts/palantir_wiki_watchdog.py'
            proc = subprocess.run([sys.executable, str(launcher), '--launcher-check'],
                capture_output=True, text=True, timeout=20)
            self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
            snapshot = json.loads(proc.stdout)
            self.assertEqual(snapshot['audit_dir'], plan['audit_dir'])
            self.assertEqual(snapshot['project_id'], plan['project_id'])
            self.assertEqual(snapshot['hermes_home'], plan['hermes_home'])
            self.assertFalse((home / 'cron/jobs.json').exists())

    def test_resume_refuses_a_changed_code_release(self):
        with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as tmp:
            home = Path(tmp)
            plan = self.prepared(home)
            install.apply_plan(plan, plan['digest'])
            code_file = Path(plan['engine_dir']) / 'wikiconfig.py'
            code_file.write_bytes(code_file.read_bytes() + b'\n# Different unreviewed release\n')
            with self.assertRaises(wikiconfig.ConfigError):
                install.apply_plan(plan, plan['digest'])

    def test_engine_only_apply_records_location_and_preserves_inbox(self):
        with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as tmp:
            home = Path(tmp)
            wiki, data = home / 'wiki', home / 'data'
            (wiki / '.llm-wiki').mkdir(parents=True)
            (wiki / '.llm-wiki/project.json').write_text('{"id":"fixture"}')
            (wiki / 'wiki').mkdir()
            (wiki / 'wiki/index.md').write_text('# Fixture index\n')
            (data / 'inbox/retained').mkdir(parents=True)
            retained = data / 'inbox/retained/source.md'
            retained.write_bytes(b'Owner work that must survive installation\n')
            cfg = {'project_root': str(wiki), 'project_id': 'fixture', 'hermes_home': str(home),
                'audit_dir': str(data), 'install_options': {'no_plugin': True, 'no_cron': True},
                'schedule': {'watchdog': '15 8 * * *'}}
            (data / 'settings.json').write_bytes(json.dumps(cfg).encode())
            plan = install.build_plan(cfg, home, Path(__file__).resolve().parents[1], data)
            with patch.object(install, 'hermes_cli', side_effect=AssertionError('Engine-only setup must not reinstall panels')):
                result = install.apply_plan(plan, plan['digest'])
            self.assertTrue(result['ok'])
            location = json.loads((home / 'state/wiki-automation/location.json').read_bytes())
            self.assertEqual(location['engine_dir'], plan['engine_dir'])
            self.assertEqual(location['audit_dir'], str(data.resolve()))
            self.assertEqual(retained.read_bytes(), b'Owner work that must survive installation\n')
            self.assertEqual(json.loads((data / 'settings.json').read_bytes())['schedule']['watchdog'], '15 8 * * *')
            self.assertFalse((home / 'cron/jobs.json').exists())
            settings_stamp = (data / 'settings.json').stat().st_mtime_ns
            location_stamp = (home / 'state/wiki-automation/location.json').stat().st_mtime_ns
            self.assertEqual(install.apply_plan(plan, plan['digest']), result)
            self.assertEqual((data / 'settings.json').stat().st_mtime_ns, settings_stamp)
            self.assertEqual((home / 'state/wiki-automation/location.json').stat().st_mtime_ns, location_stamp)
            import sqlite3
            from contextlib import closing
            with closing(sqlite3.connect(home / 'state/wiki-automation/installation.sqlite')) as database:
                self.assertEqual(database.execute('SELECT COUNT(*) FROM operations').fetchone()[0], 1)

    def test_install_preview_is_readonly_and_binds_all_existing_state(self):
        with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as tmp:
            home = Path(tmp)
            wiki, data = home / 'wiki', home / 'data'
            (wiki / '.llm-wiki').mkdir(parents=True)
            (wiki / '.llm-wiki/project.json').write_text('{"id":"fixture"}')
            (wiki / 'raw').mkdir()
            (wiki / 'wiki').mkdir()
            (wiki / 'wiki/index.md').write_text('# Fixture index\n')
            data.mkdir()
            settings = data / 'settings.json'
            cfg = {'project_root': str(wiki), 'project_id': 'fixture', 'hermes_home': str(home),
                'audit_dir': str(data), 'schedule': {'watchdog': '15 8 * * *'}}
            settings.write_bytes(json.dumps(cfg).encode())
            before = {str(path): path.read_bytes() for path in home.rglob('*') if path.is_file()}
            plan = install.build_plan(cfg, home, Path(__file__).resolve().parents[1], data)
            self.assertEqual(plan['audit_dir'], str(data.resolve()))
            self.assertEqual(plan['settings']['schedule']['watchdog'], '15 8 * * *')
            self.assertEqual(install.build_plan(cfg, home, Path(__file__).resolve().parents[1], data), plan)
            self.assertEqual(len(plan['digest']), 64)
            self.assertEqual(before, {str(path): path.read_bytes() for path in home.rglob('*') if path.is_file()})
            settings.write_bytes(json.dumps({**cfg, 'schedule': {'watchdog': '0 7 * * *'}}).encode())
            changed = install.build_plan(cfg, home, Path(__file__).resolve().parents[1], data)
            self.assertNotEqual(changed['digest'], plan['digest'])

    def test_configured_missing_profile_never_selects_a_different_home(self):
        with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as tmp:
            home = Path(tmp)
            with patch.dict(os.environ, {'HERMES_HOME': str(home)}), self.assertRaises(wikiconfig.ConfigError):
                wikiconfig.hermes_home({'hermes_home': str(home / 'missing-profile')})

    def test_profile_location_selects_code_without_replacing_data(self):
        with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as tmp:
            home = Path(tmp)
            code, data = home / 'releases/fixture', home / 'data'
            code.mkdir(parents=True)
            data.mkdir()
            location = home / 'state/wiki-automation/location.json'
            location.parent.mkdir(parents=True)
            for record in ({'audit_dir': str(code)}, {'schema': 2, 'engine_dir': str(code), 'audit_dir': str(data)}):
                location.write_bytes(json.dumps(record).encode())
                cfg = {'hermes_home': str(home), 'audit_dir': str(data)}
                before = location.read_bytes()
                self.assertEqual(wikiconfig.engine_dir(cfg), code)
                self.assertEqual(wikiconfig.audit_dir(cfg), data)
                self.assertEqual(location.read_bytes(), before)

    def test_corrupt_existing_settings_are_never_reset_on_save(self):
        with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as tmp:
            path = Path(tmp) / 'settings.json'
            original = b'{broken owner settings'
            path.write_bytes(original)
            with patch.dict(os.environ, {'LLMWIKI_SETTINGS': str(path)}), self.assertRaises(wikiconfig.ConfigError):
                wikiconfig.save({'project_root': str(Path(tmp) / 'wiki')})
            self.assertEqual(path.read_bytes(), original)

    def test_configured_missing_data_never_falls_back_into_code(self):
        with tempfile.TemporaryDirectory(dir=os.environ['TMPDIR']) as tmp:
            missing = Path(tmp) / 'missing-data'
            with self.assertRaises(wikiconfig.ConfigError):
                wikiconfig.audit_dir({'audit_dir': str(missing)})
            self.assertFalse(missing.exists())


if __name__ == '__main__':
    unittest.main()
