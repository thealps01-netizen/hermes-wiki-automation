"""Disposable collection/outcome tests never read installed agent histories."""
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import wiki_session_harvest as harvest
from workflow_store import WorkflowStore


class HarvestLifecycleTests(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory(dir=os.environ.get('TMPDIR'))
        self.addCleanup(tmp.cleanup)
        self.audit = Path(tmp.name)
        self.run = self.audit / 'inbox/run-one'
        (self.run / 'conversations').mkdir(parents=True)
        (self.run / 'candidates').mkdir()
        (self.run / 'conversations/one.md').write_bytes(b'Owner said something; assistant claims success')
        self.manifest = {'run': 'run-one', 'project_id': 'fixture', 'execution_id': 'execution-one', 'job_id': 'job-one',
            'agents': {'hermes': '1 conversation(s)'}, 'cursors_to_commit': {'hermes': 100},
            'conversations': [{'files': ['conversations/one.md']}], 'committed': False,
            'input_hashes': {'conversations/one.md': hashlib.sha256((self.run / 'conversations/one.md').read_bytes()).hexdigest()}}
        (self.run / 'run.json').write_bytes(json.dumps(self.manifest).encode())
        self.outcome = {'execution_id': 'execution-one', 'job_id': 'job-one', 'status': 'no_candidates',
            'reviewed_inputs': self.manifest['input_hashes'], 'candidate_refs': [], 'missing_evidence': []}

    def finish(self, outcome=None):
        with WorkflowStore(self.audit / 'workflow.sqlite') as store:
            return harvest.finish_run(self.audit, 'run-one', self.outcome if outcome is None else outcome, store)

    def test_drafted_artifacts_are_complete_but_not_published(self):
        from draft_adapter import DraftAdapter
        wiki = self.audit / 'wiki'
        (wiki / '.llm-wiki').mkdir(parents=True)
        (wiki / '.llm-wiki/project.json').write_text('{"id":"fixture"}')
        (wiki / 'raw/sources').mkdir(parents=True)
        (wiki / 'raw/evidence').mkdir(parents=True)
        adapter = DraftAdapter(wiki, self.audit / 'inbox', 'run-one', 'execution-one', 'job-one')
        metadata = {'kind': 'new', 'target': '2026-10-09-harvest-fixture.md', 'summary': 'Fixture decision',
            'why': 'The captured owner request, not an assistant execution claim', 'evidence_ids': []}
        source = '# Fixture\n\n## Decisions\n\n**1. Fixture.**\nEvidence: none (owner-directed).\n'
        ref = adapter.submit('fixture', metadata, source)
        before = {str(path): path.read_bytes() for path in wiki.rglob('*') if path.is_file()}
        outcome = {**self.outcome, 'status': 'drafted', 'candidate_refs': [ref]}
        result = self.finish(outcome)
        self.assertEqual(result['status'], 'drafted')
        self.assertIn(ref + ':source', result['candidate_hashes'])
        self.assertEqual(before, {str(path): path.read_bytes() for path in wiki.rglob('*') if path.is_file()})
        self.assertFalse((self.run / 'candidates/fixture/applied.json').exists())
        self.assertEqual(self.finish(outcome), result)

    def test_malformed_claude_history_is_not_reported_as_an_empty_reader(self):
        claude = self.audit / 'claude'
        (claude / 'project').mkdir(parents=True)
        (claude / 'project/corrupt.jsonl').write_bytes(b'{broken historical message\n')
        with self.assertRaises(harvest.HarvestError):
            list(harvest.read_claude(claude, 0, float('inf')))

    def test_malformed_codex_history_is_not_reported_as_an_empty_reader(self):
        codex = self.audit / 'codex'
        (codex / 'sessions').mkdir(parents=True)
        (codex / 'sessions/corrupt.jsonl').write_bytes(b'{broken historical message\n')
        with self.assertRaises(harvest.HarvestError):
            list(harvest.read_codex(codex, 0, float('inf')))

    def test_host_outcome_is_disabled_unless_explicitly_activated(self):
        import io
        wire = json.dumps({'run_id': 'run-one', 'outcome': self.outcome}).encode()
        for flag in (None, False, 'true', 1):
            with self.subTest(flag=flag), patch.object(harvest.wikiconfig, 'load', return_value={
                    'hermes_home': str(self.audit), 'harvest_workflow_enabled': flag}), \
                    patch.object(harvest.wikiconfig, 'project_root', return_value=self.audit), \
                    patch.object(harvest.wikiconfig, 'audit_dir', return_value=self.audit), \
                    patch.object(sys, 'stdin', io.TextIOWrapper(io.BytesIO(wire))):
                self.assertEqual(harvest.main(['--host-outcome', '--home', str(self.audit),
                    '--execution-id', 'execution-one', '--job-id', 'job-one']), 1)
                self.assertFalse((self.audit / 'harvest-state.json').exists())
                self.assertFalse((self.audit / 'workflow.sqlite').exists())

    def test_generated_prompt_uses_only_the_bound_data_contract(self):
        text = (Path(__file__).resolve().parents[1] / 'harvest_prompt.md').read_text(encoding='utf-8')
        self.assertNotIn('--commit', text, 'Prompt still requests an agent-side completion bypass')
        self.assertIn('wiki_draft_read', text)
        self.assertIn('wiki_draft_submit', text)
        self.assertIn('no_candidates', text)

    def test_bound_empty_collection_is_a_durable_domain_input(self):
        import contextlib
        import io
        cfg = {'harvest': {'agents': {name: name == 'hermes' for name in harvest.READERS}}}
        with patch.object(harvest.wikiconfig, 'load', return_value=cfg), \
                patch.object(harvest.wikiconfig, 'project_root', return_value=self.audit), \
                patch.object(harvest.wikiconfig, 'audit_dir', return_value=self.audit), \
                patch.object(harvest, 'agent_roots', return_value={'hermes': self.audit}), \
                patch.dict(harvest.READERS, {'hermes': lambda *args: []}):
            stream = io.StringIO()
            with contextlib.redirect_stdout(stream):
                self.assertEqual(harvest.main(['--execution-id', 'execution-native', '--job-id', 'job-native']), 0)
            report = json.loads(stream.getvalue().splitlines()[-1])
            self.assertIn('run_id', report, 'Empty native collection has no durable domain outcome to finish')
            manifest = json.loads((self.audit / 'inbox' / report['run_id'] / 'run.json').read_bytes())
            self.assertEqual(manifest['conversations'], [])
            self.assertFalse(manifest['committed'])
        self.assertFalse((self.audit / 'harvest-state.json').exists())

    def test_collector_reports_reader_failure_as_failure_not_empty_success(self):
        import contextlib
        import io
        cfg = {'harvest': {'agents': {name: name == 'hermes' for name in harvest.READERS}}}
        with patch.object(harvest.wikiconfig, 'load', return_value=cfg), \
                patch.object(harvest.wikiconfig, 'project_root', return_value=self.audit), \
                patch.object(harvest.wikiconfig, 'audit_dir', return_value=self.audit), \
                patch.object(harvest, 'agent_roots', return_value={'hermes': self.audit}), \
                patch.dict(harvest.READERS, {'hermes': lambda *args: (_ for _ in ()).throw(ValueError('Fixture unreadable'))}):
            stream = io.StringIO()
            with contextlib.redirect_stdout(stream):
                self.assertEqual(harvest.main(['--execution-id', 'execution-native', '--job-id', 'job-native']), 1)
            report = json.loads(stream.getvalue().splitlines()[-1])
            self.assertEqual(report['status'], 'partial')
            self.assertFalse(report['wakeAgent'])
        self.assertFalse((self.audit / 'harvest-state.json').exists())

    def test_collector_captures_a_unique_host_bound_snapshot(self):
        import contextlib
        import io
        cfg = {'harvest': {'agents': {name: name == 'hermes' for name in harvest.READERS}}}
        reader = lambda root, since, until: [('one', 'Fixture', [(1, 'user', 'Full owner text')])]
        manifests = []
        with patch.object(harvest.wikiconfig, 'load', return_value=cfg), \
                patch.object(harvest.wikiconfig, 'project_root', return_value=self.audit), \
                patch.object(harvest.wikiconfig, 'audit_dir', return_value=self.audit), \
                patch.object(harvest, 'agent_roots', return_value={'hermes': self.audit}), \
                patch.dict(harvest.READERS, {'hermes': reader}):
            for occurrence in range(2):
                stream = io.StringIO()
                with contextlib.redirect_stdout(stream):
                    self.assertEqual(harvest.main(['--execution-id', 'execution-native', '--job-id', 'job-native']), 0)
                reply = json.loads(stream.getvalue().splitlines()[-1])
                manifest = json.loads((self.audit / 'inbox' / reply['run_id'] / 'run.json').read_bytes())
                self.assertEqual(manifest['execution_id'], 'execution-native')
                self.assertEqual(manifest['job_id'], 'job-native')
                for name, digest in manifest['input_hashes'].items():
                    self.assertEqual(hashlib.sha256((self.audit / 'inbox' / reply['run_id'] / name).read_bytes()).hexdigest(), digest)
                manifests.append(reply['run_id'])
        self.assertEqual(len(set(manifests)), 2)

    def test_real_process_death_replays_each_cursor_and_manifest_checkpoint(self):
        import candidate_apply
        import shutil
        import subprocess
        points = []
        def make_case(name):
            case = self.audit / name
            shutil.copytree(self.run, case / 'inbox/run-one')
            (case / 'outcome.json').write_bytes(json.dumps(self.outcome).encode())
            return case
        trace = make_case('trace')
        with patch.object(candidate_apply, '_checkpoint', side_effect=points.append), WorkflowStore(trace / 'workflow.sqlite') as store:
            harvest.finish_run(trace, 'run-one', self.outcome, store)
        recovered = 0
        for number, point in enumerate(dict.fromkeys(points)):
            with self.subTest(checkpoint=point):
                case = make_case(f'crash-{number}')
                worker = subprocess.run([sys.executable, str(Path(__file__).with_name('harvest_finish_worker.py')), str(case), point],
                    capture_output=True, timeout=20)
                self.assertEqual(worker.returncode, 91, worker.stderr.decode(errors='replace'))
                with WorkflowStore(case / 'workflow.sqlite') as store:
                    harvest.finish_run(case, 'run-one', self.outcome, store)
                    count = store.db.execute('SELECT COUNT(*) FROM operations').fetchone()[0]
                    self.assertEqual(count, 1)
                    self.assertEqual(harvest.load_state(case / 'harvest-state.json')['cursors']['hermes'], 100)
                    state_bytes = (case / 'harvest-state.json').read_bytes()
                    harvest.finish_run(case, 'run-one', self.outcome, store)
                    self.assertEqual((case / 'harvest-state.json').read_bytes(), state_bytes)
                self.assertTrue(json.loads((case / 'inbox/run-one/run.json').read_bytes())['committed'])
                recovered += 1
        self.assertGreaterEqual(recovered, 6)
        print(f'HARVEST_INTERRUPTION_CASES recovered={recovered}')

    def test_legacy_agent_commit_cannot_mark_processing_complete(self):
        with patch.object(harvest.wikiconfig, 'load', return_value={}), \
                patch.object(harvest.wikiconfig, 'project_root', return_value=self.audit), \
                patch.object(harvest.wikiconfig, 'audit_dir', return_value=self.audit):
            self.assertEqual(harvest.main(['--commit', 'run-one']), 1)
        self.assertTrue(self.run.exists())
        self.assertFalse((self.audit / 'harvest-state.json').exists())
        self.assertFalse(json.loads((self.run / 'run.json').read_bytes())['committed'])

    def test_corrupt_state_is_not_first_run(self):
        path = self.audit / 'harvest-state.json'
        path.write_bytes(b'{broken')
        with self.assertRaises(RuntimeError):
            harvest.load_state(path)
        self.assertEqual(path.read_bytes(), b'{broken')

    def test_no_candidates_is_explicit_completion(self):
        with self.assertRaises(RuntimeError):
            self.finish({'assistant_said': 'success'})
        self.assertFalse((self.audit / 'harvest-state.json').exists())
        result = self.finish()
        self.assertEqual(result['status'], 'no_candidates')
        self.assertEqual(harvest.load_state(self.audit / 'harvest-state.json')['cursors']['hermes'], 100)

    def test_repeated_finish_is_noop_and_old_run_cannot_rewind(self):
        (self.audit / 'harvest-state.json').write_text('{"cursors":{"hermes":200}}')
        first = self.finish()
        path = self.audit / 'harvest-state.json'
        stamp = path.stat().st_mtime_ns
        self.assertEqual(self.finish(), first)
        self.assertEqual(path.stat().st_mtime_ns, stamp)
        self.assertEqual(harvest.load_state(path)['cursors']['hermes'], 200)

    def test_reader_failure_does_not_advance(self):
        self.manifest['agents']['codex'] = 'UNREADABLE (ValueError)'
        (self.run / 'run.json').write_bytes(json.dumps(self.manifest).encode())
        with self.assertRaises(RuntimeError):
            self.finish()
        self.assertFalse((self.audit / 'harvest-state.json').exists())

    def test_incomplete_or_changed_artifacts_cannot_finish(self):
        (self.run / 'conversations/one.md').unlink()
        with self.assertRaises(RuntimeError):
            self.finish()
        self.assertFalse((self.audit / 'harvest-state.json').exists())

    def test_user_text_is_not_silently_clipped(self):
        text = 'u' * (harvest.USER_CLIP + 17)
        rendered, clip = harvest.render('Fixture', [(1, 'user', text)], 10000)
        self.assertIn(text, '\n'.join(rendered))


if __name__ == '__main__':
    unittest.main()
