"""Recovery mechanics use disposable projects; no live entry point is enabled."""
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


class OperationLockTests(unittest.TestCase):
    def test_two_processes_serialize_and_process_death_releases_lock(self):
        from candidate_apply import operation_lock, ApplyRefused
        with tempfile.TemporaryDirectory(dir=os.environ.get('TMPDIR')) as tmp:
            root = Path(tmp)
            worker = Path(__file__).with_name('candidate_apply_worker.py')
            with operation_lock(root):
                denied = subprocess.run([sys.executable, str(worker), 'lock', str(root)], capture_output=True, text=True, timeout=10)
                self.assertEqual(denied.returncode, 2, denied.stdout + denied.stderr)
                self.assertIn('Operation lock is busy', denied.stdout)
            proc = subprocess.Popen([sys.executable, str(worker), 'hold-lock', str(root)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            try:
                self.assertEqual(proc.stdout.readline().strip(), 'LOCKED')
                with self.assertRaises(ApplyRefused):
                    with operation_lock(root, timeout=0):
                        self.fail('Two independent processes acquired the same lock')
            finally:
                proc.kill()
                proc.communicate(timeout=10)
            with operation_lock(root, timeout=0):
                self.assertTrue((root / 'operation.lock').is_file())


class CandidateApplyTests(unittest.TestCase):
    def setUp(self):
        import json
        self.temp = tempfile.TemporaryDirectory(dir=os.environ.get('TMPDIR'))
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.wiki, self.data = self.root / 'wiki', self.root / 'data'
        self.inbox = self.data / 'inbox'
        (self.wiki / '.llm-wiki').mkdir(parents=True)
        (self.wiki / '.llm-wiki/project.json').write_bytes(b'{"id":"recovery-fixture"}')
        (self.wiki / 'raw/sources').mkdir(parents=True)
        (self.wiki / 'raw/evidence').mkdir()
        self.candidate = self.inbox / 'run/candidates/draft'
        self.candidate.mkdir(parents=True)
        self.target = self.wiki / 'raw/sources/2026-10-08-fixture.md'
        self.metadata = {'kind': 'new', 'target': self.target.name, 'summary': 'Fixture', 'why': 'Test', 'evidence_ids': []}
        (self.candidate / 'candidate.json').write_text(json.dumps(self.metadata), encoding='utf-8')
        self.source = b'# Recovery fixture\n\n## Decisions\n\n**1. Fixture.**\nEvidence: none (method).\n'
        (self.candidate / 'source.md').write_bytes(self.source)

    def authorize(self):
        from owner_decisions import OwnerDecisions
        from wiki_candidates import review_snapshot
        self.snapshot = review_snapshot(self.wiki, self.inbox, 'run/draft')
        with OwnerDecisions(self.data, initialize=True) as authority:
            request = authority.prepare(self.snapshot, 'fixture-owner')
            self.approval = authority.confirm(request['request_id'], self.snapshot, 'fixture-owner')

    def configure_recovery(self, kind):
        import hashlib
        import json
        evidence = self.candidate / 'evidence/fixture-code'
        evidence.mkdir(parents=True)
        payload = b'Exact stored evidence'
        (evidence / 'payload.txt').write_bytes(payload)
        (evidence / 'manifest.json').write_text(json.dumps({'schema': 1, 'evidence_id': 'fixture-code', 'used_by': [],
            'files': {'payload.txt': {'sha256': hashlib.sha256(payload).hexdigest()}}}), encoding='utf-8')
        self.metadata.update(kind=kind, evidence_ids=['fixture-code'])
        self.source = self.source.replace(b'none (method)', b'fixture-code')
        (self.candidate / 'source.md').write_bytes(self.source)
        if kind != 'new':
            original = self.source.replace(b'Recovery fixture', b'Original fixture')
            self.target.write_bytes(original)
            self.metadata['base_sha256'] = hashlib.sha256(original).hexdigest()
        if kind == 'retire':
            import shutil
            shutil.copytree(evidence, self.wiki / 'raw/evidence/fixture-code')
            (self.candidate / 'source.md').unlink()
            manifest = self.wiki / 'raw/evidence/fixture-code/manifest.json'
            value = json.loads(manifest.read_bytes())
            value['used_by'] = [self.target.name]
            manifest.write_text(json.dumps(value), encoding='utf-8')
        (self.candidate / 'candidate.json').write_text(json.dumps(self.metadata), encoding='utf-8')

    def test_failure_at_every_step_reconciles(self):
        for kind in ('new', 'update', 'retire'):
            fixture = CandidateApplyTests('test_repeated_applied_operation_is_noop')
            fixture.setUp()
            try:
                fixture.configure_recovery(kind)
                fixture.assert_interruption_recovery(kind)
            finally:
                fixture.doCleanups()

    def assert_interruption_recovery(self, kind):
        import json
        from candidate_apply import apply_candidate
        from workflow_store import WorkflowStore
        from unittest.mock import patch
        import candidate_apply
        self.authorize()
        trace = []
        with WorkflowStore(self.data / 'workflow.sqlite') as store, patch.object(candidate_apply, '_checkpoint', trace.append):
            apply_candidate(self.wiki, self.inbox, 'run/draft', self.snapshot, self.approval, store)
        self.assertIn('before-record:operation', trace)
        self.assertIn('after-consume:authority', trace)
        self.assertIn('before-transition:applied', trace)
        prepared_name = 'source.md' if kind != 'retire' else 'manifest.json'
        self.assertIn(f'after-temp:{prepared_name}', trace)
        self.assertIn(f'before-replace:{prepared_name}', trace)
        worker = Path(__file__).with_name('candidate_apply_worker.py')
        for index, point in enumerate(trace):
            with self.subTest(point=point):
                fixture = CandidateApplyTests('test_repeated_applied_operation_is_noop')
                fixture.setUp()
                try:
                    fixture.configure_recovery(kind)
                    fixture.authorize()
                    request = fixture.root / 'worker-request.json'
                    request.write_text(json.dumps({'wiki': str(fixture.wiki), 'inbox': str(fixture.inbox),
                        'snapshot': fixture.snapshot, 'approval': fixture.approval}), encoding='utf-8')
                    killed = subprocess.run([sys.executable, str(worker), 'apply', str(request), str(index)], capture_output=True, text=True, timeout=10)
                    self.assertEqual(killed.returncode, 91, killed.stdout + killed.stderr)
                    stamp = fixture.target.stat().st_mtime_ns if fixture.target.exists() and fixture.target.read_bytes() == fixture.source else None
                    recovered = subprocess.run([sys.executable, str(worker), 'apply', str(request)], capture_output=True, text=True, timeout=10)
                    self.assertEqual(recovered.returncode, 0, recovered.stdout + recovered.stderr)
                    if kind == 'retire':
                        self.assertFalse(fixture.target.exists())
                    else:
                        self.assertEqual(fixture.target.read_bytes(), fixture.source)
                    manifest = json.loads((fixture.wiki / 'raw/evidence/fixture-code/manifest.json').read_bytes())
                    self.assertEqual(manifest['used_by'], [] if kind == 'retire' else [fixture.target.name])
                    if stamp is not None:
                        self.assertEqual(fixture.target.stat().st_mtime_ns, stamp, 'Recovery rewrote already published bytes')
                    with WorkflowStore(fixture.data / 'workflow.sqlite') as store:
                        rows = store.db.execute('SELECT id,state FROM operations').fetchall()
                        self.assertEqual(len(rows), 1)
                        self.assertEqual(rows[0][1], 'applied')
                finally:
                    fixture.doCleanups()
        print(f'INTERRUPTION_MATRIX kind={kind} recovered={len(trace)} checkpoints={len(trace)}')

    def test_update_and_retire_preserve_expected_version(self):
        import hashlib
        import json
        from candidate_apply import apply_candidate
        from workflow_store import WorkflowStore
        for kind in ('update', 'retire'):
            with self.subTest(kind=kind):
                fixture = CandidateApplyTests('test_repeated_applied_operation_is_noop')
                fixture.setUp()
                try:
                    original = b'# Previously reviewed source\n'
                    fixture.target.write_bytes(original)
                    fixture.metadata.update(kind=kind, base_sha256=hashlib.sha256(original).hexdigest())
                    (fixture.candidate / 'candidate.json').write_text(json.dumps(fixture.metadata), encoding='utf-8')
                    if kind == 'retire':
                        (fixture.candidate / 'source.md').unlink()
                    fixture.authorize()
                    with WorkflowStore(fixture.data / 'workflow.sqlite') as store:
                        result = apply_candidate(fixture.wiki, fixture.inbox, 'run/draft', fixture.snapshot, fixture.approval, store)
                        self.assertEqual(result['state'], 'applied')
                        if kind == 'retire':
                            self.assertFalse(fixture.target.exists())
                        else:
                            self.assertEqual(fixture.target.read_bytes(), fixture.source)
                        self.assertEqual((fixture.data / 'operations' / result['operation_id'] / 'base.md').read_bytes(), original)
                        self.assertEqual(apply_candidate(fixture.wiki, fixture.inbox, 'run/draft', fixture.snapshot, fixture.approval, store)['operation_id'], result['operation_id'])
                finally:
                    fixture.doCleanups()

    def test_external_drift_preserved(self):
        from candidate_apply import apply_candidate, ApplyRefused
        from workflow_store import WorkflowStore
        import candidate_apply
        from unittest.mock import patch
        self.authorize()
        with WorkflowStore(self.data / 'workflow.sqlite') as store:
            def stop_after_source(point):
                if point == 'after-step:source':
                    raise InterruptedError('Simulated interruption after journaled source')
            with patch.object(candidate_apply, '_checkpoint', stop_after_source):
                with self.assertRaises(InterruptedError):
                    apply_candidate(self.wiki, self.inbox, 'run/draft', self.snapshot, self.approval, store)
            self.target.unlink()
            with self.assertRaises(ApplyRefused):
                apply_candidate(self.wiki, self.inbox, 'run/draft', self.snapshot, self.approval, store)
            self.assertFalse(self.target.exists(), 'Deleted source was recreated over an external decision')
            operation = store.db.execute('SELECT id,state FROM operations').fetchone()
            self.assertEqual(operation[1], 'recovery_required')
            self.target.write_bytes(b'Independent newer content')
            with self.assertRaises(ApplyRefused):
                apply_candidate(self.wiki, self.inbox, 'run/draft', self.snapshot, self.approval, store)
            self.assertEqual(self.target.read_bytes(), b'Independent newer content')

    def test_evidence_is_prepared_before_source_and_attribution_is_reconciled(self):
        import hashlib
        import json
        from candidate_apply import apply_candidate
        from workflow_store import WorkflowStore
        from unittest.mock import patch
        import candidate_apply
        evidence = self.candidate / 'evidence/fixture-code'
        evidence.mkdir(parents=True)
        payload = b'Exact stored evidence'
        (evidence / 'payload.txt').write_bytes(payload)
        (evidence / 'manifest.json').write_text(json.dumps({'schema': 1, 'evidence_id': 'fixture-code', 'used_by': [],
            'files': {'payload.txt': {'sha256': hashlib.sha256(payload).hexdigest()}}}), encoding='utf-8')
        self.metadata['evidence_ids'] = ['fixture-code']
        (self.candidate / 'candidate.json').write_text(json.dumps(self.metadata), encoding='utf-8')
        self.source = self.source.replace(b'none (method)', b'fixture-code')
        (self.candidate / 'source.md').write_bytes(self.source)
        self.authorize()
        def observe(point):
            if point == f'before-write:{self.target.name}':
                self.assertEqual((self.wiki / 'raw/evidence/fixture-code/payload.txt').read_bytes(), payload)
        with WorkflowStore(self.data / 'workflow.sqlite') as store, patch.object(candidate_apply, '_checkpoint', observe):
            result = apply_candidate(self.wiki, self.inbox, 'run/draft', self.snapshot, self.approval, store)
            manifest = self.wiki / 'raw/evidence/fixture-code/manifest.json'
            self.assertEqual(json.loads(manifest.read_bytes())['used_by'], [self.target.name])
            stamp = manifest.stat().st_mtime_ns
            self.assertEqual(apply_candidate(self.wiki, self.inbox, 'run/draft', self.snapshot, self.approval, store)['operation_id'], result['operation_id'])
            self.assertEqual(manifest.stat().st_mtime_ns, stamp)

    def test_recovery_rejects_changed_candidate_inputs(self):
        from candidate_apply import apply_candidate, ApplyRefused
        from workflow_store import WorkflowStore
        import candidate_apply
        from unittest.mock import patch
        self.authorize()
        with WorkflowStore(self.data / 'workflow.sqlite') as store:
            def stop_before_consume(point):
                if point == 'before-consume:authority':
                    raise InterruptedError('Simulated interruption before consuming authorization')
            with patch.object(candidate_apply, '_checkpoint', stop_before_consume):
                with self.assertRaises(InterruptedError):
                    apply_candidate(self.wiki, self.inbox, 'run/draft', self.snapshot, self.approval, store)
            (self.candidate / 'source.md').write_bytes(b'# Independent changed draft\n')
            with self.assertRaises(ApplyRefused):
                apply_candidate(self.wiki, self.inbox, 'run/draft', self.snapshot, self.approval, store)
            self.assertFalse(self.target.exists())

    def test_missing_or_forged_authority_never_publishes(self):
        from candidate_apply import apply_candidate
        from workflow_store import WorkflowStore
        from owner_decisions import DecisionRefused
        self.authorize()
        forged = {**self.approval, 'signature': '0' * 64}
        with WorkflowStore(self.data / 'workflow.sqlite') as store:
            with self.assertRaises(DecisionRefused):
                apply_candidate(self.wiki, self.inbox, 'run/draft', self.snapshot, forged, store)
            self.assertFalse(self.target.exists())
            self.assertEqual(store.db.execute('SELECT COUNT(*) FROM operations').fetchone()[0], 0)

    def test_reject_preserves_recoverable_reason(self):
        import json
        from candidate_apply import reject_candidate
        import candidate_apply
        from unittest.mock import patch
        reason = 'Owner rejected unsupported claims'
        def stop_before_move(point):
            if point == 'before-write:reject-move':
                raise InterruptedError('Simulated interruption before candidate move')
        with patch.object(candidate_apply, '_checkpoint', stop_before_move):
            with self.assertRaises(InterruptedError):
                reject_candidate(self.inbox, 'run/draft', reason)
        self.assertEqual(json.loads((self.candidate / 'rejected.json').read_bytes())['reason'], reason)
        result = reject_candidate(self.inbox, 'run/draft', reason)
        self.assertEqual(result['state'], 'rejected')
        self.assertFalse(self.candidate.exists())
        dest = self.inbox / 'rejected/run-draft'
        before = {p.relative_to(dest).as_posix(): p.read_bytes() for p in dest.rglob('*') if p.is_file()}
        self.assertEqual(reject_candidate(self.inbox, 'run/draft', reason)['operation_id'], result['operation_id'])
        self.assertEqual(before, {p.relative_to(dest).as_posix(): p.read_bytes() for p in dest.rglob('*') if p.is_file()})

    def test_legacy_marker_conflict_is_ambiguous(self):
        import json
        from candidate_apply import reconcile_legacy
        from workflow_store import WorkflowStore
        marker = self.candidate / 'applied.json'
        marker.write_text(json.dumps({'kind': 'new', 'target': self.target.name}), encoding='utf-8')
        self.target.write_bytes(b'Independent source, not the proposed bytes')
        with WorkflowStore(self.data / 'workflow.sqlite') as store:
            before = {p.relative_to(self.root).as_posix(): p.read_bytes() for p in self.root.rglob('*') if p.is_file()}
            rows = reconcile_legacy(self.wiki, self.inbox, store)
            self.assertEqual(rows[0]['status'], 'ambiguous')
            self.assertEqual(before, {p.relative_to(self.root).as_posix(): p.read_bytes() for p in self.root.rglob('*') if p.is_file()})
            self.target.write_bytes(self.source)
            rows = reconcile_legacy(self.wiki, self.inbox, store)
            self.assertEqual(rows[0]['status'], 'verified')
            self.assertEqual(store.db.execute('SELECT COUNT(*) FROM operations').fetchone()[0], 0)
            rows = reconcile_legacy(self.wiki, self.inbox, store, import_verified=True)
            self.assertEqual(rows[0]['status'], 'imported')
            self.assertEqual(store.db.execute('SELECT COUNT(*) FROM operations').fetchone()[0], 1)
            self.assertEqual(self.target.read_bytes(), self.source)

    def test_applied_evidence_drift_is_reported_without_repair(self):
        from candidate_apply import apply_candidate
        from workflow_store import WorkflowStore
        self.configure_recovery('new')
        self.authorize()
        with WorkflowStore(self.data / 'workflow.sqlite') as store:
            apply_candidate(self.wiki, self.inbox, 'run/draft', self.snapshot, self.approval, store)
            payload = self.wiki / 'raw/evidence/fixture-code/payload.txt'
            payload.write_bytes(b'Independent evidence change')
            result = apply_candidate(self.wiki, self.inbox, 'run/draft', self.snapshot, self.approval, store)
            self.assertTrue(result['later_drift'])
            self.assertEqual(payload.read_bytes(), b'Independent evidence change')

    def test_journal_must_belong_to_the_selected_data_root(self):
        from candidate_apply import apply_candidate, ApplyRefused
        from workflow_store import WorkflowStore
        self.authorize()
        with WorkflowStore(self.root / 'other-data/workflow.sqlite') as store:
            with self.assertRaises(ApplyRefused):
                apply_candidate(self.wiki, self.inbox, 'run/draft', self.snapshot, self.approval, store)
        self.assertFalse(self.target.exists())

    def test_public_rejection_uses_durable_reason_path(self):
        import wiki_candidates
        import candidate_apply
        from unittest.mock import patch
        def stop_before_move(point):
            if point == 'before-write:reject-move':
                raise InterruptedError('Simulated interruption at public rejection')
        with patch.object(candidate_apply, '_checkpoint', stop_before_move):
            with self.assertRaises(InterruptedError):
                wiki_candidates.cmd_reject(self.inbox, 'run/draft', 'Unsupported source')
        self.assertTrue((self.candidate / 'rejected.json').exists())
        self.assertTrue(self.candidate.exists())
        self.assertEqual(wiki_candidates.cmd_reject(self.inbox, 'run/draft', 'Unsupported source'), 0)

    def test_public_recovery_preview_is_read_only(self):
        import contextlib
        import io
        import json
        import wiki_candidates
        from candidate_apply import apply_candidate
        from workflow_store import WorkflowStore
        self.authorize()
        with WorkflowStore(self.data / 'workflow.sqlite') as store:
            result = apply_candidate(self.wiki, self.inbox, 'run/draft', self.snapshot, self.approval, store)
        before = {p.relative_to(self.root).as_posix(): p.read_bytes() for p in self.root.rglob('*') if p.is_file()}
        with contextlib.redirect_stdout(io.StringIO()) as output:
            self.assertEqual(wiki_candidates.cmd_recover(self.wiki, self.inbox, result['operation_id'], True), 0)
        response = json.loads(output.getvalue())
        self.assertEqual(response['state'], 'applied')
        self.assertNotIn('approval', response)
        self.assertEqual(before, {p.relative_to(self.root).as_posix(): p.read_bytes() for p in self.root.rglob('*') if p.is_file()})
        with self.assertRaises(wiki_candidates.Refused):
            wiki_candidates.cmd_recover(self.wiki, self.inbox, result['operation_id'], False)

    def test_cli_reconciliation_does_not_initialize_missing_journal(self):
        import contextlib
        import io
        import json
        import wiki_candidates
        from unittest.mock import patch
        (self.candidate / 'applied.json').write_text(json.dumps({'kind': 'new', 'target': self.target.name}), encoding='utf-8')
        self.target.write_bytes(self.source)
        before = {p.relative_to(self.root).as_posix(): p.read_bytes() for p in self.root.rglob('*') if p.is_file()}
        with patch.object(wiki_candidates, 'paths', return_value=(self.wiki, self.inbox)), contextlib.redirect_stdout(io.StringIO()) as output:
            self.assertEqual(wiki_candidates.main(['reconcile', '--dry-run']), 0)
        self.assertEqual(json.loads(output.getvalue())[0]['status'], 'verified')
        self.assertFalse((self.data / 'workflow.sqlite').exists())
        self.assertEqual(before, {p.relative_to(self.root).as_posix(): p.read_bytes() for p in self.root.rglob('*') if p.is_file()})

    def test_recovery_requires_prepared_authorized_operation(self):
        from candidate_apply import reconcile_operation, ApplyRefused
        from workflow_store import WorkflowStore
        with WorkflowStore(self.data / 'workflow.sqlite') as store:
            store.record_operation({'operation_id': 'legacy-record', 'type': 'legacy-import'})
            for operation_id in ('missing', 'legacy-record', '../escape'):
                with self.subTest(operation_id=operation_id), self.assertRaises(ApplyRefused):
                    reconcile_operation(self.wiki, self.inbox, operation_id, store)
        self.assertFalse(self.target.exists())

    def test_legacy_invalid_candidate_is_reported_not_silently_skipped(self):
        import json
        from candidate_apply import reconcile_legacy
        self.metadata['kind'] = 'unsupported'
        (self.candidate / 'candidate.json').write_text(json.dumps(self.metadata), encoding='utf-8')
        (self.candidate / 'applied.json').write_bytes(b'{}')
        rows = reconcile_legacy(self.wiki, self.inbox, None)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['status'], 'ambiguous')
        self.assertIn('unknown kind', rows[0]['reason'])

    def test_two_processes_share_one_application(self):
        import json
        from workflow_store import WorkflowStore
        self.authorize()
        request = self.root / 'worker-request.json'
        request.write_text(json.dumps({'wiki': str(self.wiki), 'inbox': str(self.inbox), 'snapshot': self.snapshot,
                                      'approval': self.approval}), encoding='utf-8')
        worker = Path(__file__).with_name('candidate_apply_worker.py')
        processes = [subprocess.Popen([sys.executable, str(worker), 'apply', str(request)], stdout=subprocess.PIPE,
                                      stderr=subprocess.PIPE, text=True) for _ in range(2)]
        results = []
        try:
            for proc in processes:
                output, error = proc.communicate(timeout=20)
                self.assertEqual(proc.returncode, 0, output + error)
                results.append(json.loads(output))
        finally:
            for proc in processes:
                if proc.poll() is None:
                    proc.kill()
                    proc.communicate(timeout=10)
        self.assertEqual(results[0]['operation_id'], results[1]['operation_id'])
        self.assertEqual(self.target.read_bytes(), self.source)
        with WorkflowStore(self.data / 'workflow.sqlite', read_only=True) as store:
            self.assertEqual(store.db.execute('SELECT COUNT(*) FROM operations').fetchone()[0], 1)
            self.assertEqual(store.get_operation(results[0]['operation_id'])['state'], 'applied')

    def test_repeated_applied_operation_is_noop(self):
        from candidate_apply import apply_candidate
        from workflow_store import WorkflowStore
        self.authorize()
        with WorkflowStore(self.data / 'workflow.sqlite') as store:
            result = apply_candidate(self.wiki, self.inbox, 'run/draft', self.snapshot, self.approval, store)
            self.assertEqual(result['state'], 'applied')
            self.assertEqual(self.target.read_bytes(), self.source)
            marker = (self.candidate / 'applied.json').read_bytes()
            stamp = self.target.stat().st_mtime_ns
            again = apply_candidate(self.wiki, self.inbox, 'run/draft', self.snapshot, self.approval, store)
            self.assertEqual(again['operation_id'], result['operation_id'])
            self.assertEqual(self.target.stat().st_mtime_ns, stamp)
            self.assertEqual((self.candidate / 'applied.json').read_bytes(), marker)


if __name__ == '__main__':
    unittest.main()
