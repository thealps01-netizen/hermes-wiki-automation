"""Shared profile-scoped entry point; generated wrappers contain no engine business logic."""
import json
import os
from pathlib import Path
import re
import subprocess
import sys


def cron_exit(code, alert):
    if code is None or code == 0 or (alert and code == 1):
        return 0
    return code if isinstance(code, int) else 2


def launch(implementation, args=None):
    args = list(sys.argv[1:] if args is None else args)
    alert = implementation in ('wiki_autocommit.py', 'wiki_ingest_watch.py')
    if '--launcher-selftest' in args:
        assert cron_exit(0, True) == 0 and cron_exit(1, True) == 0
        assert cron_exit(1, False) == 1 and cron_exit(2, True) == 2
        print('[launcher selftest] alert and real-failure exit contracts hold')
        return 0
    home = Path(__file__).resolve().parent.parent
    try:
        if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*\.py', implementation):
            raise ValueError('Invalid engine implementation name')
        record = json.loads((home / 'state/wiki-automation/location.json').read_bytes())
        schema = record.get('schema', 1)
        if type(schema) is not int or schema not in (1, 2):
            raise ValueError('Unsupported engine location schema')
        code = Path(record['engine_dir'] if schema == 2 else record['audit_dir'])
        data = Path(record['audit_dir'])
        if not code.is_absolute() or not data.is_absolute() or not code.is_dir() or not data.is_dir():
            raise ValueError('Selected code or data root is missing')
        if '--launcher-check' in args:
            target, args = code / 'wikiconfig.py', ['show']
            alert = False
        else:
            target = code / implementation
        if not target.is_file():
            raise ValueError('Selected engine implementation is missing')
        env = {**os.environ, 'HERMES_HOME': str(home), 'LLMWIKI_SETTINGS': str(data / 'settings.json'),
               'LLMWIKI_AUDIT_DIR': str(code)}
        result = subprocess.run([sys.executable, '-B', str(target), *args], cwd=str(home), env=env)
        return cron_exit(result.returncode, alert)
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print(f'!! Engine launcher refused: {exc}')
        return 2
