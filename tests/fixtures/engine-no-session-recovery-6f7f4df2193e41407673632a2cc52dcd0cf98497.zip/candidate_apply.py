"""Recoverable candidate mechanics, not a public activation or owner approval endpoint."""
from contextlib import contextmanager
import errno
import os
from pathlib import Path
import time

from workflow_paths import checked_path, identifier
from owner_decisions import OwnerDecisions, canonical
from wiki_candidates import review_snapshot, load_candidate, cmd_approve, sha, Refused
import contextlib
import hashlib
import io
import json
import tempfile
import shutil
import evidence_store


def _checkpoint(name):
    return None


def _atomic(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    _checkpoint(f'before-write:{path.name}')
    fd, name = tempfile.mkstemp(prefix=f'.{path.name}.', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as handle:
            _checkpoint(f'before-temp:{path.name}')
            handle.write(data)
            handle.flush()
            _checkpoint(f'after-temp:{path.name}')
            _checkpoint(f'before-fsync:{path.name}')
            os.fsync(handle.fileno())
            _checkpoint(f'after-fsync:{path.name}')
        _checkpoint(f'before-replace:{path.name}')
        os.replace(name, path)
        _checkpoint(f'after-replace:{path.name}')
    finally:
        if os.path.exists(name):
            os.unlink(name)
    _checkpoint(f'after-write:{path.name}')


def _step(store, operation_id, name, result):
    _checkpoint(f'before-step:{name}')
    store.record_step(operation_id, name, result)
    _checkpoint(f'after-step:{name}')


def _transition(store, operation_id, expected, new):
    _checkpoint(f'before-transition:{new}')
    store.transition(operation_id, expected, new)
    _checkpoint(f'after-transition:{new}')


def _identity(snapshot, approval):
    return hashlib.sha256(canonical({'issuer': approval.get('issuer'), 'request_id': approval.get('request_id'),
                                     'review_digest': snapshot['review_digest']})).hexdigest()


def apply_candidate(wiki, inbox, ref, snapshot, approval, store):
    data = Path(inbox).parent
    if store.path.resolve() != checked_path(data, 'workflow.sqlite').resolve():
        raise ApplyRefused('Workflow journal belongs to another data root')
    operation_id = _identity(snapshot, approval)
    with operation_lock(data):
        existing = store.get_operation(operation_id)
        if existing:
            if existing.get('snapshot') != snapshot or existing.get('approval') != approval or existing.get('ref') != ref:
                raise ApplyRefused('Operation identity changed')
            return _recover(wiki, inbox, operation_id, store)
        if snapshot.get('ref') != ref or review_snapshot(wiki, inbox, ref) != snapshot:
            raise ApplyRefused('Reviewed snapshot changed')
        with OwnerDecisions(data) as authority:
            authority.verify(approval, snapshot)
        with contextlib.redirect_stdout(io.StringIO()):
            cmd_approve(wiki, inbox, ref, True)
        candidate, metadata = load_candidate(inbox, ref)
        staged = checked_path(data, f'operations/{operation_id}/source.md')
        if snapshot['kind'] != 'retire':
            source = (candidate / 'source.md').read_bytes()
            if hashlib.sha256(source).hexdigest() != snapshot['source_hash']:
                raise ApplyRefused('Draft changed during preparation')
            _atomic(staged, source)
        if snapshot['expected_base'] is not None:
            base = checked_path(wiki, f"raw/sources/{snapshot['target']}").read_bytes()
            if hashlib.sha256(base).hexdigest() != snapshot['expected_base']:
                raise ApplyRefused('Target changed during preparation')
            _atomic(staged.with_name('base.md'), base)
        for group, entries in (('evidence', snapshot['evidence']), ('stored_evidence', snapshot['stored_evidence'])):
            for entry in entries:
                origin = checked_path(candidate / 'evidence' if group == 'evidence' else Path(wiki) / 'raw/evidence', entry['path'])
                content = origin.read_bytes()
                if hashlib.sha256(content).hexdigest() != entry['sha256']:
                    raise ApplyRefused('Evidence changed during preparation')
                _atomic(checked_path(data, f"operations/{operation_id}/{group}/{entry['path']}"), content)
        if review_snapshot(wiki, inbox, ref) != snapshot:
            raise ApplyRefused('Review changed while preparation was captured')
        _checkpoint('before-record:operation')
        store.record_operation({'operation_id': operation_id, 'type': 'candidate', 'ref': ref,
                                'snapshot': snapshot, 'approval': approval})
        _checkpoint('after-record:operation')
        return _recover(wiki, inbox, operation_id, store)


def _evidence_groups(snapshot):
    groups = {}
    for group in ('evidence', 'stored_evidence'):
        for entry in snapshot[group]:
            name, relative = entry['path'].split('/', 1)
            identifier(name)
            groups.setdefault(name, {}).setdefault(group, {})[relative] = entry['sha256']
    return groups


def _publish_evidence(wiki, data, operation_id, snapshot, store):
    for name, groups in _evidence_groups(snapshot).items():
        original_group = 'stored_evidence' if 'stored_evidence' in groups else 'evidence'
        original = groups[original_group]
        staged = checked_path(data, f'operations/{operation_id}/{original_group}/{name}')
        for relative, expected in original.items():
            if sha(checked_path(staged, relative)) != expected:
                raise ApplyRefused('Prepared evidence changed')
        dest = checked_path(wiki, f'raw/evidence/{name}')
        if dest.exists():
            actual = {p.relative_to(dest).as_posix(): sha(checked_path(dest, p.relative_to(dest).as_posix()))
                      for p in dest.rglob('*') if p.is_file()}
            if {k: v for k, v in actual.items() if k != 'manifest.json'} != {k: v for k, v in original.items() if k != 'manifest.json'}:
                raise ApplyRefused('Existing evidence drift preserved')
            live_manifest = json.loads(checked_path(dest, 'manifest.json').read_bytes())
            prepared_manifest = json.loads(checked_path(staged, 'manifest.json').read_bytes())
            if {k: v for k, v in live_manifest.items() if k != 'used_by'} != {k: v for k, v in prepared_manifest.items() if k != 'used_by'}:
                raise ApplyRefused('Existing evidence manifest changed')
        else:
            if original_group == 'stored_evidence':
                raise ApplyRefused('Previously stored evidence disappeared')
            temporary = Path(tempfile.mkdtemp(prefix=f'.{name}.', dir=dest.parent))
            try:
                for relative in original:
                    _atomic(checked_path(temporary, relative), checked_path(staged, relative).read_bytes())
                _checkpoint(f'before-write:evidence-{name}')
                os.rename(temporary, dest)
                _checkpoint(f'after-write:evidence-{name}')
            finally:
                if temporary.exists():
                    shutil.rmtree(temporary)
        _step(store, operation_id, f'evidence:{name}', {'files': original})


def _sync_attribution(wiki, snapshot, operation_id, store):
    evidence_root = checked_path(wiki, 'raw/evidence')
    sources = checked_path(wiki, 'raw/sources')
    for p in [*evidence_root.rglob('*'), *sources.glob('*.md')]:
        checked_path(wiki, p.relative_to(wiki).as_posix())
    groups = _evidence_groups(snapshot)
    for name in groups:
        _checkpoint(f'before-write:attribution-{name}')
        evidence_store.sync_used_by(evidence_root, sources, only={name})
        _checkpoint(f'after-write:attribution-{name}')
    _step(store, operation_id, 'attribution', {'evidence_ids': sorted(groups)})


def _recover(wiki, inbox, operation_id, store):
    try:
        return _resume(wiki, inbox, operation_id, store)
    except ApplyRefused as exc:
        operation = store.get_operation(operation_id)
        if operation['state'] == 'applying':
            store.transition(operation_id, 'applying', 'recovery_required', {'reason': str(exc)})
        raise


def _resume(wiki, inbox, operation_id, store):
    operation = store.get_operation(operation_id)
    snapshot, approval = operation['snapshot'], operation['approval']
    data = Path(inbox).parent
    if snapshot['project_root'] != str(Path(wiki).resolve()) or sha(checked_path(wiki, '.llm-wiki/project.json')) != snapshot['project_hash']:
        raise ApplyRefused('Project identity changed')
    target = checked_path(wiki, f"raw/sources/{snapshot['target']}")
    actual = sha(target) if target.exists() else None
    desired = None if snapshot['kind'] == 'retire' else snapshot['source_hash']
    if operation['state'] == 'applied':
        drift = actual != desired
        for name, groups in _evidence_groups(snapshot).items():
            original = groups.get('stored_evidence', groups.get('evidence', {}))
            dest = checked_path(wiki, f'raw/evidence/{name}')
            payload = {p.relative_to(dest).as_posix(): sha(checked_path(dest, p.relative_to(dest).as_posix()))
                       for p in dest.rglob('*') if p.is_file() and p.name != 'manifest.json'}
            drift |= payload != {k: v for k, v in original.items() if k != 'manifest.json'}
        return {'operation_id': operation_id, 'state': 'applied', 'later_drift': drift}
    candidate, _ = load_candidate(inbox, operation['ref'])
    observed_source = sha(candidate / 'source.md') if (candidate / 'source.md').is_file() else None
    observed_evidence = [{'path': p.relative_to(candidate / 'evidence').as_posix(), 'sha256': sha(p)}
                         for p in sorted((candidate / 'evidence').rglob('*')) if p.is_file()]
    if sha(candidate / 'candidate.json') != snapshot['metadata_hash'] or observed_source != snapshot['source_hash'] or observed_evidence != snapshot['evidence']:
        raise ApplyRefused('Reviewed candidate inputs changed; review again')
    source = None
    if snapshot['kind'] != 'retire':
        source = checked_path(data, f'operations/{identifier(operation_id)}/source.md').read_bytes()
        if hashlib.sha256(source).hexdigest() != desired:
            raise ApplyRefused('Prepared source changed')
    if operation['state'] in ('collected', 'drafted'):
        if review_snapshot(wiki, inbox, operation['ref']) != snapshot:
            raise ApplyRefused('Reviewed snapshot changed before authorization consumption')
        if operation['state'] == 'collected':
            _transition(store, operation_id, 'collected', 'drafted')
        _transition(store, operation_id, 'drafted', 'awaiting_approval')
        operation = store.get_operation(operation_id)
    _checkpoint('before-consume:authority')
    with OwnerDecisions(data) as authority:
        authority.consume(approval, snapshot, operation_id)
    _checkpoint('after-consume:authority')
    _step(store, operation_id, 'authority', {'request_id': approval['request_id']})
    if operation['state'] == 'awaiting_approval':
        _transition(store, operation_id, 'awaiting_approval', 'applying')
    recorded = {step['step'] for step in store.steps(operation_id)}
    if actual not in (snapshot['expected_base'], desired) or ('source' in recorded and actual != desired):
        raise ApplyRefused('Target drift preserved; recovery requires review')
    if operation['state'] == 'recovery_required':
        _transition(store, operation_id, 'recovery_required', 'applying')
    _publish_evidence(wiki, data, operation_id, snapshot, store)
    if actual != desired:
        if snapshot['kind'] == 'retire':
            _checkpoint('before-write:retire')
            target.unlink()
            _checkpoint('after-write:retire')
        else:
            _atomic(target, source)
    if (sha(target) if target.exists() else None) != desired:
        raise ApplyRefused('Source publication could not be verified')
    _step(store, operation_id, 'source', {'sha256': desired})
    _sync_attribution(wiki, snapshot, operation_id, store)
    candidate, _ = load_candidate(inbox, operation['ref'])
    marker = canonical({'operation_id': operation_id, 'kind': snapshot['kind'], 'target': snapshot['target'],
                        'review_digest': snapshot['review_digest'], 'source_hash': snapshot['source_hash']}) + b'\n'
    marker_path = checked_path(inbox, f"{operation['ref'].split('/')[0]}/candidates/{operation['ref'].split('/')[1]}/applied.json")
    if marker_path.exists():
        if marker_path.read_bytes() != marker:
            raise ApplyRefused('Conflicting application marker')
    else:
        _atomic(marker_path, marker)
    _step(store, operation_id, 'marker', {'sha256': hashlib.sha256(marker).hexdigest()})
    _transition(store, operation_id, 'applying', 'applied')
    return {'operation_id': operation_id, 'state': 'applied', 'later_drift': False}


def reconcile_operation(wiki, inbox, operation_id, store):
    from workflow_paths import PathRefused
    try:
        identifier(operation_id)
    except PathRefused as exc:
        raise ApplyRefused('Valid operation identity is required') from exc
    data = Path(inbox).parent
    if store.path.resolve() != checked_path(data, 'workflow.sqlite').resolve():
        raise ApplyRefused('Workflow journal belongs to another data root')
    with operation_lock(data):
        operation = store.get_operation(operation_id)
        if not operation or operation.get('type') != 'candidate' or not isinstance(operation.get('approval'), dict):
            raise ApplyRefused('Recovery requires a prepared owner-authorized candidate operation')
        if _identity(operation['snapshot'], operation['approval']) != operation_id:
            raise ApplyRefused('Prepared operation identity changed')
        return _recover(wiki, inbox, operation_id, store)


def reject_candidate(inbox, ref, reason):
    from workflow_store import WorkflowStore
    if not isinstance(reason, str) or not reason.strip():
        raise ApplyRefused('A nonempty rejection reason is required')
    parts = ref.split('/')
    if len(parts) != 2:
        raise ApplyRefused('Candidate reference requires run/name')
    run, name = map(identifier, parts)
    data = Path(inbox).parent
    with operation_lock(data):
        candidate = checked_path(inbox, f'{run}/candidates/{name}')
        destination = checked_path(inbox, f'rejected/{run}-{name}')
        if candidate.exists() and destination.exists():
            raise ApplyRefused('Rejected destination already exists; neither copy was changed')
        folder = candidate if candidate.exists() else destination
        if not folder.is_dir():
            raise ApplyRefused('Candidate and rejected copy are both missing')
        metadata_path = checked_path(folder, 'candidate.json')
        identity = {'type': 'rejection', 'ref': ref, 'reason': reason, 'metadata_hash': sha(metadata_path)}
        operation_id = hashlib.sha256(canonical(identity)).hexdigest()
        record = {**identity, 'operation_id': operation_id}
        marker = canonical({'operation_id': operation_id, 'ref': ref, 'reason': reason}) + b'\n'
        reason_path = checked_path(folder, 'rejected.json')
        if reason_path.exists() and reason_path.read_bytes() != marker:
            raise ApplyRefused('Existing rejection decision differs')
        with WorkflowStore(checked_path(data, 'workflow.sqlite')) as store:
            if not candidate.exists() and store.get_operation(operation_id) is None:
                raise ApplyRefused('Moved candidate has no durable rejection record')
            store.record_operation(record)
            if not reason_path.exists():
                _atomic(reason_path, marker)
            if store.get_operation(operation_id)['state'] == 'collected':
                _transition(store, operation_id, 'collected', 'rejected')
            if candidate.exists():
                destination.parent.mkdir(parents=True, exist_ok=True)
                _checkpoint('before-write:reject-move')
                os.rename(candidate, destination)
                _checkpoint('after-write:reject-move')
            _step(store, operation_id, 'rejection', {'reason': reason, 'destination': destination.name})
        return {'operation_id': operation_id, 'state': 'rejected'}


def reconcile_legacy(wiki, inbox, store, import_verified=False):
    rows = []
    for marker_path in sorted(Path(inbox).glob('*/candidates/*/applied.json')):
        ref = f'{marker_path.parent.parent.parent.name}/{marker_path.parent.name}'
        row = {'ref': ref, 'status': 'ambiguous'}
        try:
            candidate, metadata = load_candidate(inbox, ref)
            marker = json.loads(checked_path(candidate, 'applied.json').read_bytes())
            target = checked_path(wiki, f"raw/sources/{metadata['target']}")
            if marker.get('kind') != metadata['kind'] or marker.get('target') != metadata['target']:
                raise ApplyRefused('Marker does not describe this candidate')
            if metadata['kind'] == 'retire':
                raise ApplyRefused('Absence plus a legacy marker does not prove retirement')
            source = checked_path(candidate, 'source.md')
            if not target.is_file() or sha(target) != sha(source):
                raise ApplyRefused('Current source disagrees with the marked candidate')
            for name in metadata.get('evidence_ids', []):
                dest = checked_path(wiki, f'raw/evidence/{identifier(name)}')
                if not dest.is_dir() or not (dest / 'manifest.json').is_file():
                    raise ApplyRefused('Legacy evidence is incomplete')
                original = candidate / 'evidence' / name
                if original.is_dir():
                    for p in [*original.rglob('*'), *dest.rglob('*')]:
                        checked_path(original if p.is_relative_to(original) else dest, p.relative_to(original if p.is_relative_to(original) else dest).as_posix())
                    from wiki_candidates import same_evidence
                    if not same_evidence(original, dest):
                        raise ApplyRefused('Legacy evidence payload disagrees')
                manifest = json.loads(checked_path(dest, 'manifest.json').read_bytes())
                cites, _ = evidence_store.citations(wiki / 'raw/sources', {name})
                if manifest.get('used_by') != sorted(cites.get(name, set())):
                    raise ApplyRefused('Legacy attribution disagrees with source citations')
            row['status'] = 'verified'
            if import_verified:
                identity = {'type': 'legacy-import', 'ref': ref, 'source_hash': sha(target), 'marker_hash': sha(marker_path)}
                operation_id = hashlib.sha256(canonical(identity)).hexdigest()
                operation = store.record_operation({**identity, 'operation_id': operation_id})
                for expected, new in [('collected', 'drafted'), ('drafted', 'awaiting_approval'), ('awaiting_approval', 'applying'), ('applying', 'applied')]:
                    if operation['state'] == expected:
                        operation = store.transition(operation_id, expected, new, {'verification': 'legacy content agreement only, not owner authorization'})
                row.update(status='imported', operation_id=operation_id)
        except (OSError, ValueError, RuntimeError, Refused) as exc:
            row['reason'] = str(exc)
        rows.append(row)
    return rows


class ApplyRefused(RuntimeError):
    pass


@contextmanager
def operation_lock(data_root: Path, *, timeout=10):
    path = checked_path(data_root, 'operation.lock')
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a+b') as handle:
        if path.stat().st_size == 0:
            handle.write(b'\0')
            handle.flush()
        deadline = time.monotonic() + timeout
        while True:
            try:
                handle.seek(0)
                if os.name == 'nt':
                    import msvcrt
                    msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except OSError as exc:
                if exc.errno not in (errno.EACCES, errno.EAGAIN, errno.EDEADLK):
                    raise
                if time.monotonic() >= deadline:
                    raise ApplyRefused('Operation lock is busy; the existing owner was not disturbed') from exc
                time.sleep(min(0.05, max(0, deadline - time.monotonic())))
        try:
            yield
        finally:
            handle.seek(0)
            if os.name == 'nt':
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
