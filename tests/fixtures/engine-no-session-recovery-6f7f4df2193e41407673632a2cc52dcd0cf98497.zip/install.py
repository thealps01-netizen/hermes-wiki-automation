"""Tek komutla kurulum ve TAŞIMA — wiki otomasyonunu yeni bir PC'ye kurar.

NEDEN VAR: otomasyon (ingest watch · auto-commit · watchdog · panel) artık
makineye özel yol taşımıyor; bütün yollar `settings.json`ten geliyor. Bu script o dosyayı yazar,
parçaları Hermes klasörlerine kopyalar, zamanlanmış işleri kurar ve SONUNDA gerçekten koşarak
kurulumu doğrular. Yeni PC'de tek adım:

    python install.py --project-root "D:/Wiki/Palantir"

Mevcut kurulumu onarmak/doğrulamak için argümansız çalıştırılır. Hiçbir şey yazmadan görmek için
`--dry-run`. Atlanacak adımlar: `--no-cron` (zamanlanmış işler), `--no-plugin` (panel).

Kurduğu parçalar:
  1. `settings.json`  — proje kökü (doğrulanır), otomasyon klasörü, Hermes home, kapılar, zamanlama
  2. `hermes/scripts/palantir_wiki_*.py` — cron giriş noktaları (bu paketin `launchers/` kopyasından)
  3. Paneller — Hermes'in sabitli Git kurulumu: `panels.json`daki depo ve commit
     (`hermes plugins install <depo> --ref <commit>`); masaüstü kopyasını uygulama kendisi alır
  4. Zamanlanmış işler (Hermes cron): auto-commit · ingest watch · watchdog
  5. DOĞRULAMA: scriptler gerçekten koşar, cron kayıtları okunur, `next_run_at` beklenen pencerede mi

Doğrulama başarısızsa script 1 ile çıkar ve hangi parçanın eksik olduğunu satır satır yazar.
"""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import wikiconfig  # tek ayar kaynağı

AUDIT = Path(__file__).resolve().parent
LAUNCHER_DIR = AUDIT / "launchers"
# Panels: each one is its own repository, installed by Hermes as a pinned Git install. panels.json
# names the repository and the exact commit this engine release was verified with; the engine keeps
# no copy of a panel. A new panel is one more entry there.
# `wiki-watchdog` was removed: wiki-automation 2.0.0 shows its run log as the Health tab (the
# `hermes-wiki-watchdog` repo keeps its history).
PANELS = json.loads((AUDIT / "panels.json").read_text(encoding="utf-8"))["panels"]
# Jobs come from ONE definition in this package (jobs.json); panels read the same file.
_JOB_DEFS = json.loads((AUDIT / "jobs.json").read_text(encoding="utf-8"))["jobs"]
LAUNCHERS = tuple(j["launcher"] for j in _JOB_DEFS.values())
# Script jobs. The name is the one already shown in the user's Jobs list ("Watch Dog"); a rename on
# migration would split the run history in two.
JOBS = tuple((k, j["name"], j["launcher"]) for k, j in _JOB_DEFS.items() if j["kind"] == "script")
# AGENT JOBS: a pre-run script gathers the input and gates the run ({"wakeAgent": false} = no model
# cost); the prompt file in this package is the agent's whole instruction. Created PAUSED on a new
# PC: the owner turns it on after checking it.
AGENT_JOBS = tuple((k, j["name"], j["launcher"], j["prompt_file"])
                   for k, j in _JOB_DEFS.items() if j["kind"] == "agent")

report: list[tuple[str, str]] = []


def note(ok: bool, text: str) -> None:
    report.append(("OK  " if ok else "EKSİK", text))
    print(f"  [{'✓' if ok else '×'}] {text}")


def run(cmd: list[str], timeout: int = 300) -> tuple[int, str]:
    proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="ignore",
                          timeout=timeout)
    return proc.returncode, (proc.stdout or "") + (proc.stderr or "")


def hermes_cli(args: list[str]) -> tuple[int, str]:
    return run([sys.executable, "-m", "hermes_cli.main"] + args)


def read_jobs(hermes_home: Path) -> list[dict]:
    path = hermes_home / "cron" / "jobs.json"
    if not path.exists():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    jobs = data.get("jobs", data) if isinstance(data, dict) else data
    if isinstance(jobs, dict):
        jobs = list(jobs.values())
    return [j for j in jobs if isinstance(j, dict)]


def job_by_name(hermes_home: Path, name: str) -> dict | None:
    for job in read_jobs(hermes_home):
        if str(job.get("name") or "").strip().lower() == name.lower():
            return job
    return None


def write_location(hermes_home: Path, dry: bool) -> None:
    """Paketin YERİNİ Hermes home'a yaz: klasör taşınırsa panel buradan bulur.

    Neden: panel otomasyon klasörünü sırayla `LLMWIKI_AUDIT_DIR` → bu kayıt → `~/.llmwiki-audit`
    diye arar. Kayıt olmadan, taşınan bir paket "kurulu değil" görünüyordu (taşınabilirliğin asıl
    vaadi buydu). Kayıt KÜÇÜKTÜR ve yalnız yolu tutar; sır içermez.
    """
    target = hermes_home / "state" / "wiki-automation"
    if dry:
        note(True, f"konum kaydı yazılacaktı → {target / 'location.json'}")
        return
    try:
        target.mkdir(parents=True, exist_ok=True)
        record = {"audit_dir": str(AUDIT), "written_by": "install.py"}
        (target / "location.json").write_text(
            json.dumps(record, indent=2, ensure_ascii=False) + chr(10), encoding="utf-8")
    except OSError as exc:
        note(False, f"konum kaydı yazılamadı: {exc}")
        return
    note(True, f"konum kaydı → {target / 'location.json'}")


def copy_launchers(hermes_home: Path, dry: bool) -> int:
    """Cron giriş noktalarını Hermes scripts klasörüne kopyala. Kaynak: bu paketin `launchers/`."""
    target = hermes_home / "scripts"
    if not LAUNCHER_DIR.is_dir():
        note(False, f"launchers/ klasörü yok ({LAUNCHER_DIR}) — cron giriş noktaları kopyalanamadı")
        return 0
    if not dry:
        target.mkdir(parents=True, exist_ok=True)
    copied = 0
    for name in LAUNCHERS:
        src = LAUNCHER_DIR / name
        if not src.exists():
            note(False, f"launcher eksik: {name}")
            continue
        if not dry:
            shutil.copy2(src, target / name)
        copied += 1
    note(copied == len(LAUNCHERS), f"{copied}/{len(LAUNCHERS)} cron giriş noktası → {target}")
    return copied


def install_panels(hermes_home: Path, dry: bool, force: bool = False) -> None:
    """Install each panel in panels.json as a pinned Git install at the commit named there.

    Hermes does the install (`hermes plugins install <repo> --ref <commit>`) and records it in
    plugins/.install-metadata.json; the desktop app copies the panel's desktop half itself. A panel that
    is present but not pinned at that commit is reported and left alone: it may be pinned elsewhere on
    purpose or hold work. `--force` moves it to the engine's commit, except a git checkout with
    uncommitted changes, which is never replaced.
    """
    meta = _install_metadata(hermes_home)
    for name, pin in PANELS.items():
        _install_one_panel(hermes_home, name, pin["repo"], pin["commit"], meta.get(name), dry, force)


def _install_metadata(hermes_home: Path) -> dict:
    path = hermes_home / "plugins" / ".install-metadata.json"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def _uncommitted(live: Path) -> bool:
    if not (live / ".git").exists():
        return False
    proc = subprocess.run(["git", "-C", str(live), "status", "--porcelain"], capture_output=True,
                          text=True)
    return proc.returncode != 0 or bool(proc.stdout.strip())


def _install_one_panel(hermes_home: Path, name: str, repo: str, commit: str, row, dry: bool,
                       force: bool) -> None:
    live = hermes_home / "plugins" / name
    pinned = isinstance(row, dict) and row.get("pinned") is True
    if live.is_dir() and pinned and row.get("revision") == commit:
        note(True, f"{name}: {commit[:8]} commit'ine sabitli")
        return
    if live.is_dir() and not force:
        where = (f"{str(row.get('revision'))[:8]} commit'ine sabitli" if pinned
                 else "sabitlenmemiş bir kopya")
        note(True, f"{name}: {where}, motorun commit'i {commit[:8]} — dokunulmadı (taşımak için --force)")
        return
    if live.is_dir() and _uncommitted(live):
        note(False, f"{name}: canlı panelde commit edilmemiş değişiklik var — üzerine kurulmadı")
        return
    args = ["plugins", "install", repo, "--ref", commit, "--enable"] + (["--force"] if live.is_dir() else [])
    if dry:
        note(True, f"{name}: kurulacak → hermes {' '.join(args)}")
        return
    code, out = hermes_cli(args)
    row = _install_metadata(hermes_home).get(name)
    ok = (code == 0 and isinstance(row, dict) and row.get("pinned") is True
          and row.get("revision") == commit)
    note(ok, f"{name}: {repo} @ {commit[:8]} sabitli kuruldu" + ("" if ok else f" ({out.strip()[-160:]})"))


def install_wiki_hooks(root: Path, dry: bool) -> None:
    """Copy the engine's wiki-hooks/ into <wiki>/.githooks/ and point git at it.

    The engine owns the hooks; the wiki holds a generated copy. A hand edit in the wiki copy is
    overwritten here, which is the point: fix the hook in wiki-hooks/ and re-run install.py."""
    src = AUDIT / "wiki-hooks"
    dst = root / ".githooks"
    names = sorted(p.name for p in src.glob("*") if p.is_file()) if src.is_dir() else []
    if not names:
        note(False, f"wiki-hooks/ yok ya da boş ({src}) — commit kancaları kurulamadı")
        return
    if not dry:
        dst.mkdir(exist_ok=True)
        for n in names:
            (dst / n).write_bytes((src / n).read_bytes().replace(b"\r\n", b"\n"))
        subprocess.run(["git", "-C", str(root), "config", "core.hooksPath", ".githooks"],
                       capture_output=True, text=True)
    same = not dry and all((dst / n).read_bytes() == (src / n).read_bytes().replace(b"\r\n", b"\n")
                           for n in names)
    note(dry or same, f"commit kancaları ({', '.join(names)}) → {dst}")


def sync_jobs(cfg: dict, hermes_home: Path, dry: bool) -> dict:
    """Üç zamanlanmış işi kur/tazele. Var olan iş güncellenir (kopya üretilmez)."""
    ids = dict(cfg.get("jobs") or {})
    schedule = cfg.get("schedule") or {}
    deliver = cfg.get("deliver") or "local"
    for key, name, script in JOBS:
        sched = schedule.get(key) or _JOB_DEFS[key].get("default_schedule")
        desc = _JOB_DEFS[key].get("description") or ""
        if not sched:
            note(False, f"zamanlama tanımsız: schedule.{key}")
            continue
        existing = job_by_name(hermes_home, name)
        if existing:
            if not dry:
                code, out = hermes_cli(["cron", "edit", str(existing.get("id")), "--schedule", sched,
                                        "--script", script, "--no-agent", "--deliver", deliver,
                                        "--prompt", desc])
                if code != 0:
                    note(False, f"iş güncellenemedi: {name} ({out.strip()[:120]})")
                    continue
            ids[key] = existing.get("id")
            note(True, f"iş güncellendi: {name} ({sched})")
        else:
            if dry:
                note(True, f"iş kurulacak: {name} ({sched})")
                continue
            code, out = hermes_cli(["cron", "create", sched, desc, "--name", name, "--script", script,
                                    "--no-agent", "--deliver", deliver])
            created = job_by_name(hermes_home, name)
            if code != 0 or not created:
                note(False, f"iş kurulamadı: {name} ({out.strip()[:120]})")
                continue
            ids[key] = created.get("id")
            note(True, f"iş kuruldu: {name} ({sched})")
    if not dry and ids != (cfg.get("jobs") or {}):
        wikiconfig.save({"jobs": ids})
    return ids


def agent_prompt(prompt_file: str) -> str:
    """The job prompt: the package's instruction file with this PC's folders filled in, so the
    stored prompt never carries another machine's paths."""
    text = (AUDIT / prompt_file).read_text(encoding="utf-8")
    cfg = wikiconfig.load()
    header = (f"Automation folder: {AUDIT}\nWiki root: {wikiconfig.project_root(cfg)}\n"
              f"Python for the scripts: {sys.executable}\nThe run folder is in the job context "
              f"(`run_dir`).\n\n")
    return header + text


def sync_agent_jobs(cfg: dict, hermes_home: Path, dry: bool) -> None:
    schedule = cfg.get("schedule") or {}
    deliver = cfg.get("deliver") or "local"
    ids = dict(cfg.get("jobs") or {})
    for key, name, script, prompt_file in AGENT_JOBS:
        sched = schedule.get(key) or _JOB_DEFS[key].get("default_schedule")
        prompt = agent_prompt(prompt_file)
        existing = job_by_name(hermes_home, name)
        if dry:
            note(True, f"ajan işi {'güncellenecek' if existing else 'kurulacak (duraklatılmış)'}: {name} ({sched})")
            continue
        if existing:
            code, out = hermes_cli(["cron", "edit", str(existing.get("id")), "--schedule", sched,
                                    "--script", script, "--prompt", prompt, "--deliver", deliver])
            ok = code == 0
            ids[key] = existing.get("id")
            note(ok, f"ajan işi güncellendi: {name} ({sched})" + ("" if ok else f" ({out.strip()[:120]})"))
        else:
            code, out = hermes_cli(["cron", "create", sched, prompt, "--name", name, "--script", script,
                                    "--deliver", deliver, "--paused",
                                    "--paused-reason", "new install: turn on after checking the first run"])
            created = job_by_name(hermes_home, name)
            ok = code == 0 and created is not None
            if created:
                ids[key] = created.get("id")
            note(ok, f"ajan işi kuruldu (duraklatılmış): {name} ({sched})" + ("" if ok else f" ({out.strip()[:120]})"))
    if not dry and ids != (cfg.get("jobs") or {}):
        wikiconfig.save({"jobs": ids})


def verify(cfg: dict, hermes_home: Path, dry: bool) -> bool:
    """Kurulumu İDDİAYLA değil KOŞARAK doğrula: scriptler + cron kayıtları + sonraki koşu zamanı."""
    ok = True
    for label, script, args in (("auto-commit (dry-run)", "wiki_autocommit.py", ["--dry-run"]),
                                ("ingest watch", "wiki_ingest_watch.py", []),
                                ("watchdog", "watchdog.py", [])):
        target = AUDIT / script
        if not target.exists():
            note(False, f"{label}: script yok ({target})")
            ok = False
            continue
        if dry:
            note(True, f"{label}: koşulacak")
            continue
        try:
            code, out = run([sys.executable, str(target)] + args, timeout=300)
        except subprocess.TimeoutExpired:
            note(False, f"{label}: zaman aşımı")
            ok = False
            continue
        # 0 = temiz, 1 = bulgu var (uyarı yolu). 2+ = gerçek hata.
        note(code <= 1, f"{label}: çıkış {code}" + ("" if code <= 1 else f" ({out.strip()[:120]})"))
        ok = ok and code <= 1

    # Cron kayıtları: iş gerçekten var mı ve SONRAKİ KOŞU beklenen pencerede mi?
    for key, name, _ in JOBS:
        job = job_by_name(hermes_home, name)
        if not job:
            note(False, f"cron işi yok: {name}")
            ok = False
            continue
        sched = job.get("schedule") or {}
        display = sched.get("display") or sched.get("expr") or sched.get("kind")
        nxt = str(job.get("next_run_at") or "")
        if sched.get("kind") == "interval":
            note(False, f"{name}: zamanlama aralık olarak kayıtlı ({display}) — cron söz dizimi beklenirdi")
            ok = False
            continue
        note(True, f"{name}: {display} · sonraki {nxt[:16]}")
    return ok


def code_fingerprints(code: Path) -> dict:
    import hashlib
    from workflow_paths import checked_path
    sources = sorted([*code.glob('*.py'), *code.glob('launchers/*.py'),
        *[code / name for name in ('jobs.json', 'panels.json', 'harvest_prompt.md') if (code / name).is_file()]])
    return {path.relative_to(code).as_posix(): hashlib.sha256(
        checked_path(code, path.relative_to(code).as_posix()).read_bytes()).hexdigest() for path in sources}


def launcher_payloads(code: Path, definitions: dict) -> dict:
    from workflow_paths import checked_path
    payloads = {'_wiki_engine_bootstrap.py': checked_path(code, 'launchers/_wiki_engine_bootstrap.py').read_bytes().hex()}
    for spec in definitions.values():
        name, implementation = spec['launcher'], spec['impl']
        checked_path(code, 'launchers/' + name)
        checked_path(code, implementation)
        content = "from _wiki_engine_bootstrap import launch\nraise SystemExit(launch(" + repr(implementation) + "))\n"
        payloads[name] = content.encode('utf-8').hex()
    return payloads


def build_plan(cfg: dict, hermes_home: Path, code_root: Path, data_root: Path) -> dict:
    """Build a repair-free, stable engine-owned preview; this function creates nothing."""
    import hashlib
    from owner_decisions import canonical
    from workflow_paths import checked_path
    home, code, data = map(lambda path: Path(path).resolve(), (hermes_home, code_root, data_root))
    if not home.is_dir() or not code.is_dir():
        raise wikiconfig.ConfigError('Existing selected profile and staged code roots are required')
    if cfg.get('hermes_home') and Path(cfg['hermes_home']).resolve() != home:
        raise wikiconfig.ConfigError('Install preview belongs to a different profile')
    info = wikiconfig.validate_project(cfg.get('project_root') or '')
    if not info['ok']:
        raise wikiconfig.ConfigError('Project identity must be verified before installation preview')
    if cfg.get('project_id') and cfg['project_id'] != info['id']:
        raise wikiconfig.ConfigError('Configured project identity changed')
    state_paths = {'settings': checked_path(data, 'settings.json'),
        'location': checked_path(home, 'state/wiki-automation/location.json'),
        'jobs': checked_path(home, 'cron/jobs.json')}
    before, captured = {}, {}
    for key, path in state_paths.items():
        if not path.exists():
            before[key], captured[key] = None, None
            continue
        raw = path.read_bytes()
        before[key] = hashlib.sha256(raw).hexdigest()
        try:
            captured[key] = json.loads(raw)
            if not isinstance(captured[key], dict):
                raise ValueError('Stored object is not a dictionary')
        except (ValueError, OSError) as exc:
            raise wikiconfig.ConfigError(f'Existing {key} is unreadable; no installation fallback is allowed') from exc
    if captured['location'] is not None:
        _previous_code, previous_data = wikiconfig.validate_location(captured['location'])
        if previous_data.resolve() != data:
            raise wikiconfig.ConfigError('Existing mutable data root must be retained; migration is not authorized')
    records = (captured['jobs'] or {}).get('jobs', [])
    if not isinstance(records, list) or any(not isinstance(job, dict) or not job.get('id') for job in records):
        raise wikiconfig.ConfigError('Existing job store shape is unsupported; no repair is performed')
    settings = wikiconfig._merge(cfg, captured['settings'] or {})
    if 'install_options' in cfg:
        settings['install_options'] = dict(cfg['install_options'])
    settings.update(project_root=info['path'], project_id=info['id'], hermes_home=str(home),
        engine_dir=str(code), audit_dir=str(data))
    definitions = json.loads(checked_path(code, 'jobs.json').read_bytes())['jobs']
    if not isinstance(definitions, dict):
        raise wikiconfig.ConfigError('Engine job definitions are malformed')
    payloads = launcher_payloads(code, definitions)
    launcher_before = {}
    old_location = captured['location'] or {}
    for name, encoded in payloads.items():
        target = checked_path(home, 'scripts/' + name)
        existing = target.read_bytes() if target.exists() else None
        observed = hashlib.sha256(existing).hexdigest() if existing is not None else None
        launcher_before[name] = observed
        if existing is not None and existing != bytes.fromhex(encoded):
            owned_hash = (old_location.get('launcher_hashes') or {}).get(name)
            if owned_hash is None and old_location.get('written_by') == 'install.py' and old_location.get('audit_dir'):
                previous_source = checked_path(Path(old_location['audit_dir']), 'launchers/' + name)
                if previous_source.is_file():
                    owned_hash = hashlib.sha256(previous_source.read_bytes()).hexdigest()
            if owned_hash != observed:
                raise wikiconfig.ConfigError('Existing same-name launcher is customized or unowned; it was preserved')
    code_hashes = code_fingerprints(code)
    plan = {'schema': 1, 'hermes_home': str(home), 'engine_dir': str(code), 'audit_dir': str(data),
        'project_id': info['id'], 'settings_path': str(state_paths['settings']), 'settings': settings,
        'before_hashes': before, 'existing_jobs': records, 'job_definitions': definitions,
        'code_hashes': code_hashes, 'launcher_payloads': payloads, 'launcher_before': launcher_before, 'location': {'schema': 2, 'engine_dir': str(code),
            'audit_dir': str(data), 'written_by': 'engine.install',
            'launcher_hashes': {name: hashlib.sha256(bytes.fromhex(content)).hexdigest() for name, content in payloads.items()}}}
    plan['digest'] = hashlib.sha256(canonical(plan)).hexdigest()
    return plan


def verify_job_role(job: dict, role: str, plan: dict) -> None:
    spec = plan['job_definitions'][role]
    agent = spec['kind'] == 'agent'
    if (job.get('name') != spec['name'] or job.get('no_agent') is not (not agent)
            or job.get('script') != (None if agent else spec['launcher'])):
        raise wikiconfig.ConfigError('Mapped job is not the selected engine role; owner work was preserved')
    if agent and (set(job.get('enabled_toolsets') or []) != {'wiki_draft', 'no_mcp'}
            or job.get('workdir') != plan['settings']['project_root']):
        raise wikiconfig.ConfigError('Legacy or customized drafting job requires a separate reviewed migration')


def register_paused_jobs(plan: dict, store) -> dict:
    from hermes_constants import set_hermes_home_override, reset_hermes_home_override
    from cron.jobs import use_cron_store, list_jobs, create_job, get_job
    from candidate_apply import _checkpoint
    home = Path(plan['hermes_home'])
    mapping = dict(plan['settings'].get('jobs') or {})
    token = set_hermes_home_override(home)
    try:
        with use_cron_store(home):
            for role in plan['job_definitions']:
                previous = get_job(mapping.get(role)) if mapping.get(role) else None
                if previous is not None:
                    verify_job_role(previous, role, plan)
            for role, spec in plan['job_definitions'].items():
                marker = {'engine_installation': plan['digest'], 'engine_role': role}
                rows = list_jobs(include_disabled=True)
                matches = [row for row in rows if row.get('origin') == marker]
                if len(matches) > 1:
                    raise wikiconfig.ConfigError('Ambiguous saved installation job; no duplicate was created')
                previous = next((row for row in rows if row['id'] == mapping.get(role)), None)
                if matches:
                    job = get_job(matches[0]['id'])
                elif previous is not None:
                    previous = get_job(previous['id'])
                    captured = next((row for row in plan['existing_jobs'] if row['id'] == previous['id']), None)
                    if captured != previous:
                        raise wikiconfig.ConfigError('Managed job changed after preview; customized record was preserved')
                    job = previous
                else:
                    if any(row.get('name') == spec['name'] for row in rows):
                        raise wikiconfig.ConfigError('Same-name job has no verified installation ownership; it was preserved')
                    agent = spec['kind'] == 'agent'
                    prompt = (Path(plan['engine_dir']) / spec['prompt_file']).read_text(encoding='utf-8') if agent else spec['description']
                    job = create_job(prompt=prompt,
                        schedule=(plan['settings'].get('schedule') or {}).get(role) or spec['default_schedule'],
                        name=spec['name'], repeat=None, deliver=plan['settings'].get('deliver') or 'local',
                        origin=marker, script=None if agent else spec['launcher'], no_agent=not agent,
                        enabled_toolsets=['wiki_draft', 'no_mcp'] if agent else [],
                        workdir=plan['settings']['project_root'], paused=True,
                        paused_reason='Created by the verified engine installer; owner activation required.',
                        interpreter=None if agent else sys.executable)
                    _checkpoint('after-create-job:' + role)
                verify_job_role(job, role, plan)
                saved = get_job(job['id'])
                if saved != job:
                    raise wikiconfig.ConfigError('Native installation job readback disagreed')
                mapping[role] = job['id']
                store.record_step(plan['digest'], 'job-' + role, {'job_id': job['id'], 'origin': job.get('origin')})
            return mapping
    finally:
        reset_hermes_home_override(token)


def apply_plan(plan: dict, expected_digest: str) -> dict:
    """Apply the verified engine-only location slice; scheduler integration is separately gated."""
    import hashlib
    from candidate_apply import operation_lock, _atomic
    from owner_decisions import canonical
    from workflow_paths import checked_path
    from workflow_store import WorkflowStore
    unsigned = {key: value for key, value in plan.items() if key != 'digest'}
    if expected_digest != plan.get('digest') or hashlib.sha256(canonical(unsigned)).hexdigest() != expected_digest:
        raise wikiconfig.ConfigError('Installation confirmation does not match the exact preview')
    options = plan['settings'].get('install_options') or {}
    if options.get('no_plugin') is not True or type(options.get('no_cron')) is not bool:
        raise wikiconfig.ConfigError('Engine-only panel-free scope and explicit scheduler choice are required')
    home, code, data = map(Path, (plan['hermes_home'], plan['engine_dir'], plan['audit_dir']))
    project = wikiconfig.validate_project(plan['settings']['project_root'])
    if not project['ok'] or project['id'] != plan['project_id']:
        raise wikiconfig.ConfigError('Selected project identity changed; original confirmation is invalid')
    if code_fingerprints(code) != plan['code_hashes']:
        raise wikiconfig.ConfigError('Selected code release changed after preview; retry is refused')
    meta = checked_path(home, 'state/wiki-automation')
    with operation_lock(meta), operation_lock(data), WorkflowStore(checked_path(meta, 'installation.sqlite')) as store:
        source_journal = checked_path(data, 'workflow.sqlite')
        if source_journal.exists():
            with WorkflowStore(source_journal, read_only=True) as workflow:
                if workflow.db.execute("SELECT 1 FROM operations WHERE state IN ('applying','recovery_required') LIMIT 1").fetchone():
                    raise wikiconfig.ConfigError('Unfinished source application must be recovered before installation')
        operation = store.get_operation(expected_digest)
        if operation is None:
            current = build_plan(plan['settings'], home, code, data)
            if current['digest'] != expected_digest:
                raise wikiconfig.ConfigError('Installation inputs changed after preview')
            store.record_operation({'operation_id': expected_digest, 'type': 'installation', 'plan': plan})
        elif operation.get('plan') != plan:
            raise wikiconfig.ConfigError('Existing installation identity changed')
        operation = store.get_operation(expected_digest)
        if operation['state'] == 'collected':
            operation = store.transition(expected_digest, 'collected', 'prepared')
        if operation['state'] in ('prepared', 'recovery_required'):
            store.transition(expected_digest, operation['state'], 'applying')
        settings = dict(plan['settings'])
        if options['no_cron'] is False:
            settings['jobs'] = register_paused_jobs(plan, store)
        writes = [('settings', checked_path(data, 'settings.json'), canonical(settings) + b'\n', plan['before_hashes']['settings'])]
        writes.extend(('launcher-' + name, checked_path(home, 'scripts/' + name), bytes.fromhex(content), plan['launcher_before'][name])
            for name, content in plan['launcher_payloads'].items())
        writes.append(('location', checked_path(home, 'state/wiki-automation/location.json'),
            canonical(plan['location']) + b'\n', plan['before_hashes']['location']))
        for key, target, wanted, expected_before in writes:
            previous = target.read_bytes() if target.exists() else None
            if previous == wanted:
                continue
            observed = hashlib.sha256(previous).hexdigest() if previous is not None else None
            if observed != expected_before:
                raise wikiconfig.ConfigError(f'Existing {key} changed; nothing was overwritten')
            store.record_step(expected_digest, 'before-' + key,
                {'path': str(target), 'bytes_hex': previous.hex() if previous is not None else None})
            _atomic(target, wanted)
            if target.read_bytes() != wanted:
                raise wikiconfig.ConfigError('Installed projection readback failed')
            store.record_step(expected_digest, 'written-' + key, {'sha256': hashlib.sha256(wanted).hexdigest()})
        result = {'ok': True, 'state': 'location_recorded', 'installation_id': expected_digest}
        operation = store.get_operation(expected_digest)
        if operation['state'] == 'applying':
            store.transition(expected_digest, 'applying', 'applied', result)
        elif operation['state'] != 'applied' or operation['result'] != result:
            raise wikiconfig.ConfigError('Installation journal state is inconsistent')
        return result


def main(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(description="Wiki otomasyonu kurulumu / taşıma")
    parser.add_argument("--project-root", help="izlenecek LLM Wiki projesinin kökü")
    parser.add_argument("--hermes-home", help="Hermes kurulumu (varsayılan: otomatik bulunur)")
    parser.add_argument("--dry-run", action="store_true", help="hiçbir şey yazmadan ne yapılacağını yaz")
    parser.add_argument("--no-cron", action="store_true", help="zamanlanmış işleri kurma")
    parser.add_argument("--no-plugin", action="store_true", help="paneli kurma")
    parser.add_argument("--force", action="store_true",
                        help="başka bir commit'te duran paneli motorun commit'ine taşı")
    parser.add_argument('--data-root', help='Selected mutable engine data, separate from this code release')
    parser.add_argument('--plan-json', action='store_true')
    parser.add_argument('--apply-plan', help='Previously prepared private engine plan JSON')
    parser.add_argument('--expected-digest', help='Exact reviewed plan digest')
    args = parser.parse_args(argv[1:])
    if args.data_root or args.plan_json or args.apply_plan:
        try:
            if args.apply_plan:
                plan = json.loads(Path(args.apply_plan).read_bytes())
            else:
                home = Path(args.hermes_home).resolve() if args.hermes_home else wikiconfig.hermes_home({'hermes_home': None})
                data = Path(args.data_root).resolve() if args.data_root else home / 'state/wiki-automation/data'
                settings = data / 'settings.json'
                cfg = json.loads(settings.read_bytes()) if settings.exists() else {}
                if not isinstance(cfg, dict):
                    raise wikiconfig.ConfigError('Selected settings must be an object')
                cfg = {**cfg, 'hermes_home': str(home), 'audit_dir': str(data),
                    'project_root': args.project_root or cfg.get('project_root'),
                    'install_options': {'no_plugin': args.no_plugin, 'no_cron': args.no_cron}}
                plan = build_plan(cfg, home, AUDIT, data)
            if args.plan_json or args.dry_run:
                print(json.dumps(plan, ensure_ascii=False))
                return 0
            result = apply_plan(plan, args.expected_digest)
            print(json.dumps(result))
            return 0
        except (wikiconfig.ConfigError, OSError, ValueError, KeyError, TypeError) as exc:
            print(json.dumps({'ok': False, 'state': 'refused', 'reason': str(exc)}))
            return 1

    print(f"otomasyon klasörü: {AUDIT}")
    cfg = wikiconfig.load()

    # 1) AYAR: proje kökünü doğrula ve yaz
    root_arg = args.project_root or cfg.get("project_root")
    if not root_arg:
        print("!! proje kökü verilmedi: --project-root \"<wiki klasörü>\"")
        return 2
    info = wikiconfig.validate_project(root_arg)
    note(info["ok"], f"proje kökü: {info['path']}" + ("" if info["ok"] else f" — {info['reason']}"))
    if not info["ok"]:
        print("\nkurulum durdu: proje kökü doğrulanamadı (yanlış klasöre kurmak istemiyoruz)")
        return 2
    hermes_home = Path(args.hermes_home) if args.hermes_home else wikiconfig.hermes_home(cfg)
    patch = {"project_root": info["path"], "project_id": info["id"], "audit_dir": str(AUDIT),
             "hermes_home": str(hermes_home)}
    if args.dry_run:
        note(True, f"settings.json yazılacak: {wikiconfig.settings_path()}")
    else:
        cfg = wikiconfig.save(patch)
        note(True, f"settings.json yazıldı: {wikiconfig.settings_path()}")
    note(hermes_home.is_dir(), f"Hermes home: {hermes_home}")

    # 2) Cron giriş noktaları
    copy_launchers(hermes_home, args.dry_run)

    # 2b) Wiki commit kancaları (motorun wiki-hooks/ kopyasından)
    install_wiki_hooks(Path(info["path"]), args.dry_run)

    # 3) Panels: pinned Git installs (the desktop app copies their desktop half itself)
    if args.no_plugin:
        note(True, "panel adımı atlandı (--no-plugin)")
    else:
        install_panels(hermes_home, args.dry_run, force=args.force)
    write_location(hermes_home, args.dry_run)

    # 4) Zamanlanmış işler
    if args.no_cron:
        note(True, "cron adımı atlandı (--no-cron)")
    else:
        sync_jobs(cfg, hermes_home, args.dry_run)
        sync_agent_jobs(wikiconfig.load(), hermes_home, args.dry_run)

    # Watch Dog runs only as a Hermes cron job: Hermes runs a missed job once it is back up
    # (`cron.catch_up_missed`), so the Windows Task Scheduler twin and its popup were dropped.

    # 6) Doğrulama
    ok = verify(cfg, hermes_home, args.dry_run)

    print("\n== ÖZET ==")
    for status, text in report:
        print(f"  {status}  {text}")
    problems = [t for s, t in report if s != "OK  "]
    if problems or not ok:
        print(f"\n{len(problems)} eksik/hatalı adım var — yukarıdaki satırlara bak.")
        return 1
    print("\nkurulum tamam: scriptler koşuyor, işler kayıtlı, panel yerinde.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
