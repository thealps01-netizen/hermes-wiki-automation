"""Collect finished agent conversations since the last harvest, for wiki source candidates.

WHY: decisions made in a session reach the wiki only if someone writes them into a source. People
forget, and work happens in several agents. This script is the deterministic half of the nightly
"Wiki Session Harvest" job: it gathers what was said since the last successful harvest, from every
enabled agent (Hermes, Codex, Claude Code, Antigravity), into one inbox run folder. An agent that
is not installed on this PC is reported as "not found" and skipped; the others still run. The job's
agent step then reads that folder and drafts candidate sources (decision records plus evidence).
Nothing here writes to the wiki; candidates reach raw/sources/ only through
`wiki_candidates.py approve`, which the owner triggers.

HOW IT AVOIDS REPEATS: one cursor per agent (a timestamp) in <audit>/harvest-state.json. A run
collects messages newer than the cursor and older than the settle window, so a conversation still
in progress is taken next time. The cursor moves only when the run is committed
(`--commit <run-id>`, the agent step's last action). A failed or interrupted run leaves the cursor
where it was, so the next run collects the same messages again. A PC that was off for days is
covered by one run: the window is "since the cursor", not "today".

WHAT IS SKIPPED: subagent/worker conversations (their result reaches the parent conversation),
scheduled-job and one-shot runs, headless `codex exec` runs, and tool output. Only what the user
and the assistant said is kept. Codex conversations the owner archived (moved to
`archived_sessions/`) are read like live ones. Hermes stores a message again each time it compacts
a conversation in place; those copies are read once.
Messages the agent app writes into the user's turn are dropped too, because they are not the
owner speaking and can fill a long conversation many times over: context-compaction summaries,
subagent and background-job reports, hook feedback, goal check-ins, loaded skill text, and
embedded images. A skill or slash-command call keeps only the instruction the owner typed.

LONG CONVERSATIONS: every owner message is kept. If a conversation is still over max_chars,
assistant messages are shortened step by step; if that is not enough, the conversation is split
into ordered parts (`...-part2.md`). Nothing is dropped silently: run.json records each
conversation's `assistant_clip` and `parts`, and the agent step reports them.

OUTPUT (prints one JSON line last, for the Hermes cron pre-run gate):
  {"wakeAgent": false}                       nothing new -> the job costs nothing
  {"wakeAgent": true, "context": {...}}      run folder, session count, per-agent status

USAGE
  python wiki_session_harvest.py                 collect into a new inbox run (pre-run script)
  python wiki_session_harvest.py --status        cursors and per-agent availability, no writes
  python wiki_session_harvest.py --commit <run>  advance the cursors recorded by that run
  python wiki_session_harvest.py --since <ISO>   collect from a given time (test / backfill);
                                                 does not change any cursor on its own

SETTINGS (settings.json, key "harvest"; all optional):
  agents          {"hermes": true, "codex": true, "claude": true, "antigravity": true}
  settle_minutes  30     messages younger than this wait for the next run
  max_chars       60000  size of one conversation file; longer ones are shortened, then split
  first_run_days  2      look-back when an agent has no cursor yet
"""
from __future__ import annotations

import argparse
import hashlib
import math
import uuid
import json
import os
import re
import sqlite3
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import wikiconfig  # noqa: E402

for _s in ("stdout", "stderr"):
    try:
        getattr(sys, _s).reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

DEFAULTS = {"agents": {"hermes": True, "codex": True, "claude": True, "antigravity": True},
            "settle_minutes": 30, "max_chars": 60000, "first_run_days": 2}
ASSISTANT_CLIP = 2500           # one assistant message; decisions are stated, not dumped
CLIP_STEPS = (2500, 1200, 600, 300)   # tried in order until a conversation fits max_chars
USER_CLIP = 8000                # a pasted document is not a decision; its first part is enough
INJECTED = re.compile(r"^\s*(# AGENTS\.md instructions|<environment_context>|<user_instructions>|"
                      r"<system-reminder>|<command-name>|<local-command|Caveat:)", re.I)
# Text an agent app writes into the user's turn (not the owner speaking). Matched at the start.
APP_NOTE = re.compile(r"^\s*(\[CONTEXT COMPACTION|\[IMPORTANT: Background process|\[ASYNC DELEGATION|"
                      r"\[Request interrupted|Another Claude session sent a message|Stop hook feedback|"
                      r"A session-scoped Stop hook|Goal check-in:|<task-notification|"
                      r"<artifact-content-authored-by-others|This session is being continued from a previous|"
                      r"Base directory for this skill:|Skill /\S+ was loaded)")
DATA_URI = re.compile(r"data:[\w/+.-]+;base64,[A-Za-z0-9+/=]{200,}")
SKILL_CALL = re.compile(r"^\[IMPORTANT: The user has invoked the \"([^\"]+)\" skill.*?"
                        r"(?:The user has provided the following instruction alongside the skill "
                        r"invocation: (.*))?$", re.S)
COMMAND_CALL = re.compile(r"^\s*<command-message>.*?<command-name>([^<]*)</command-name>"
                          r"(?:\s*<command-args>(.*?)</command-args>)?", re.S)
STEER = re.compile(r"^\[OUT-OF-BAND USER MESSAGE[^\n]*\n(.*?)\n\[/OUT-OF-BAND USER MESSAGE\]\s*$", re.S)


def ts(value) -> float | None:
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00")).timestamp()
    except ValueError:
        return None


def iso(t: float) -> str:
    return datetime.fromtimestamp(t, timezone.utc).astimezone().isoformat(timespec="seconds")


def text_of(content) -> str:
    """Plain text from a message content that may be a string or a list of typed parts."""
    if isinstance(content, str) and content.startswith("\x00json:"):   # Hermes multimodal row
        try:
            content = json.loads(content[len("\x00json:"):])
        except ValueError:
            return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for p in content:
            if isinstance(p, dict) and p.get("type") in ("text", "input_text", "output_text"):
                parts.append(p.get("text") or "")
        return "\n".join(x for x in parts if x)
    return ""


def owner_text(text: str) -> str:
    """What the owner actually said in a user turn; "" when the turn is an app-written note."""
    text = DATA_URI.sub("[image omitted]", text or "").strip()
    if APP_NOTE.match(text):
        return ""
    m = SKILL_CALL.match(text)
    if m:
        return f"/{m.group(1)} {(m.group(2) or '').strip()}".strip()
    m = COMMAND_CALL.match(text)
    if m:
        return f"{m.group(1).strip()} {(m.group(2) or '').strip()}".strip()
    m = STEER.match(text)
    if m:
        return m.group(1).strip()
    return text


# ---- per-agent readers: each yields (conversation id, label, [(t, role, text)]) ----------------

def read_hermes(home: Path, since: float, until: float):
    db = home / "state.db"
    if not db.exists():
        raise FileNotFoundError(f"{db} not found")
    con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
    cols = {r[1] for r in con.execute("PRAGMA table_info(messages)")}
    app_rows = ""                                  # older Hermes versions lack these columns
    if "_compressed_summary" in cols:
        app_rows += " AND COALESCE(m._compressed_summary, 0) = 0"
    if "display_kind" in cols:
        app_rows += (" AND COALESCE(m.display_kind, '') NOT IN ('async_delegation_complete', "
                     "'process_complete', 'model_switch', 'auto_continue')")
    rows = con.execute(
        f"""SELECT s.id, COALESCE(s.title, ''), m.timestamp, m.role, m.content
           FROM messages m JOIN sessions s ON s.id = m.session_id
           WHERE m.timestamp > ? AND m.timestamp <= ? AND m.role IN ('user', 'assistant')
             AND s.parent_session_id IS NULL
             AND COALESCE(s.source, '') NOT IN ('cron', 'oneshot')
             AND COALESCE(s.title, '') NOT LIKE 'Subagent%'{app_rows}
           ORDER BY s.id, m.timestamp""", (since, until)).fetchall()
    con.close()
    # In-place compaction keeps the archived originals beside their re-inserted copies, all with the
    # same timestamp, role and content, so one message can be stored two or three times. Read each
    # once. Do not filter on Hermes' active/compacted flags instead: when compaction lands inside a
    # turn, the owner's message survives only in archived rows (its visible copy is merged into the
    # compaction summary, dropped above), and a visibility filter would lose it.
    convs: dict[str, tuple[str, list]] = {}
    seen: set[tuple] = set()
    for sid, title, t, role, content in rows:
        if (sid, t, role, content) in seen:
            continue
        seen.add((sid, t, role, content))
        convs.setdefault(sid, (title, []))[1].append((float(t), role, text_of(content or "")))
    for sid, (title, msgs) in convs.items():
        yield sid, title or sid, msgs


def read_codex(root: Path, since: float, until: float):
    """Codex home: live `sessions/` plus `archived_sessions/` (archiving moves the file there)."""
    if not (root / "sessions").is_dir():
        raise FileNotFoundError(f"{root / 'sessions'} not found")
    seen: set[str] = set()
    files = [*(root / "sessions").rglob("*.jsonl"), *(root / "archived_sessions").rglob("*.jsonl")]
    for f in sorted(files):
        if f.stem in seen:
            continue
        seen.add(f.stem)
        if f.stat().st_mtime <= since:
            continue
        msgs, meta = [], {}
        with f.open(encoding="utf-8", errors="replace") as fh:
            for line in fh:
                try:
                    d = json.loads(line)
                except ValueError as exc:
                    raise HarvestError('Codex session JSON is unreadable; the reader cannot be marked complete') from exc
                p = d.get("payload") or {}
                if d.get("type") == "session_meta":
                    meta = p
                    continue
                if p.get("type") != "message" or p.get("role") not in ("user", "assistant"):
                    continue
                t = ts(d.get("timestamp"))
                if t is None or not (since < t <= until):
                    continue
                msgs.append((t, p["role"], text_of(p.get("content"))))
        if meta.get("originator") == "codex_exec" or not msgs:
            continue
        yield f.stem, f"codex {Path(meta.get('cwd') or '').name or f.stem}", msgs


def read_claude(root: Path, since: float, until: float):
    if not root.is_dir():
        raise FileNotFoundError(f"{root} not found")
    for f in sorted(root.glob("*/*.jsonl")):          # top level only: subagents/ are workers
        if f.stat().st_mtime <= since:
            continue
        msgs, title = [], ""
        with f.open(encoding="utf-8", errors="replace") as fh:
            for line in fh:
                try:
                    d = json.loads(line)
                except ValueError as exc:
                    raise HarvestError('Claude session JSON is unreadable; the reader cannot be marked complete') from exc
                if d.get("type") == "custom-title":
                    title = d.get("customTitle") or title
                if d.get("type") not in ("user", "assistant") or d.get("isSidechain"):
                    continue
                if d.get("type") == "user" and (
                        d.get("isMeta") or d.get("isCompactSummary")
                        or (d.get("origin") or {}).get("kind") in ("task-notification", "peer")):
                    continue                           # written by Claude Code, not the owner
                t = ts(d.get("timestamp"))
                if t is None or not (since < t <= until):
                    continue
                m = d.get("message") or {}
                msgs.append((t, m.get("role") or d["type"], text_of(m.get("content"))))
        if msgs:
            yield f.stem, f"claude {title or f.parent.name}", msgs


USER_REQUEST = re.compile(r"<USER_REQUEST>\s*(.*?)\s*</USER_REQUEST>", re.S)


def read_antigravity(root: Path, since: float, until: float):
    """Antigravity: brain/<id>/.system_generated/logs/transcript_full.jsonl, one step per line.

    Kept: USER_INPUT steps (only the text inside <USER_REQUEST>, not the injected metadata) and
    PLANNER_RESPONSE steps that carry text. Tool calls, tool results (GENERIC) and thinking are
    dropped. Subagent conversations (nesting_depth > 0 in conversation_summaries.db) are skipped.
    """
    brain = root / "brain"
    if not brain.is_dir():
        raise FileNotFoundError(f"{brain} not found")
    titles, nested = {}, set()
    db = root / "conversation_summaries.db"
    if db.exists():
        con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
        for cid, title, depth, parent in con.execute(
                "SELECT conversation_id, COALESCE(title, ''), COALESCE(nesting_depth, 0), "
                "COALESCE(parent_conversation_id, '') FROM conversation_summaries"):
            titles[cid] = title
            if depth or parent:
                nested.add(cid)
        con.close()
    for f in sorted(brain.glob("*/.system_generated/logs/transcript_full.jsonl")):
        cid = f.parents[2].name
        if cid in nested or f.stat().st_mtime <= since:
            continue
        msgs = []
        with f.open(encoding="utf-8", errors="replace") as fh:
            for line in fh:
                try:
                    d = json.loads(line)
                except ValueError:
                    continue
                kind, text = d.get("type"), d.get("content")
                if kind == "USER_INPUT" and isinstance(text, str):
                    m = USER_REQUEST.search(text)
                    role, text = "user", (m.group(1) if m else text)
                elif kind == "PLANNER_RESPONSE" and isinstance(text, str) and text.strip():
                    role = "assistant"
                else:
                    continue
                t = ts(d.get("created_at"))
                if t is None or not (since < t <= until):
                    continue
                msgs.append((t, role, text))
        if msgs:
            yield cid, f"antigravity {titles.get(cid) or cid}", msgs


def agent_roots(cfg: dict) -> dict[str, Path]:
    home = Path.home()
    return {
        "hermes": wikiconfig.hermes_home(cfg),
        "codex": Path(os.environ.get("CODEX_HOME") or home / ".codex"),
        "claude": Path(os.environ.get("CLAUDE_CONFIG_DIR") or home / ".claude") / "projects",
        "antigravity": home / ".gemini" / "antigravity",
    }


READERS = {"hermes": read_hermes, "codex": read_codex, "claude": read_claude,
           "antigravity": read_antigravity}


def blocks(msgs: list, clip: int) -> list[str]:
    out = []
    for t, role, text in msgs:
        text = owner_text(text) if role == "user" else DATA_URI.sub("[image omitted]", text or "").strip()
        if not text or (role == "user" and INJECTED.match(text)):
            continue
        limit = len(text) if role == "user" else clip
        if len(text) > limit:
            text = text[:limit] + " […]"
        out.append(f"### {role} · {iso(t)}\n\n{text}\n")
    return out


def render(label: str, msgs: list, max_chars: int) -> tuple[list[str], int]:
    """(files, assistant clip used). Owner messages are never dropped: assistant messages are
    shortened first, then the conversation is split into ordered parts of at most max_chars."""
    for clip in CLIP_STEPS:
        out = blocks(msgs, clip)
        if sum(len(b) + 1 for b in out) <= max_chars:
            break
    if not out:
        return [], clip
    parts, cur = [], []
    for b in out:
        if cur and sum(len(x) + 1 for x in cur) + len(b) > max_chars:
            parts.append(cur)
            cur = []
        cur.append(b)
    parts.append(cur)
    n = len(parts)
    files = [f"# {label}" + (f" (part {i} of {n})" if n > 1 else "") + "\n\n" + "\n".join(p)
             for i, p in enumerate(parts, 1)]
    return files, clip


def source_index(wiki: Path) -> str:
    """Title, scope line and decision headings of every current source: what candidates match."""
    lines = ["# Current wiki sources (decision headings)", ""]
    for f in sorted((wiki / "raw" / "sources").glob("*.md")):
        t = f.read_text(encoding="utf-8", errors="replace")
        title = next((l[2:].strip() for l in t.splitlines() if l.startswith("# ")), f.stem)
        decisions = [re.sub(r"\s+", " ", d) for d in
                     re.findall(r"^\*\*(\d+\.\s[\s\S]+?)\*\*", t, re.M)]
        lines.append(f"## {f.name}\n{title}")
        lines += [f"- {d}" for d in decisions]
        lines.append("")
    return "\n".join(lines)


class HarvestError(RuntimeError):
    pass


def load_state(path: Path) -> dict:
    if not path.exists():
        return {'cursors': {}}
    try:
        state = json.loads(path.read_bytes())
        if not isinstance(state, dict) or not isinstance(state.get('cursors'), dict):
            raise ValueError('Invalid cursor state')
        if any(type(value) not in (int, float) or not math.isfinite(value) or value < 0
               for value in state['cursors'].values()):
            raise ValueError('Invalid cursor timestamp')
        return state
    except (OSError, ValueError) as exc:
        raise HarvestError('Existing harvest state is unreadable; preserve it and inspect before retry') from exc


def finish_run(audit: Path, run_id: str, outcome: dict, store) -> dict:
    from candidate_apply import operation_lock, _atomic
    from workflow_paths import checked_path, identifier, PathRefused
    from owner_decisions import canonical
    try:
        identifier(run_id)
        if store.path.resolve() != checked_path(audit, 'workflow.sqlite').resolve():
            raise HarvestError('Harvest journal belongs to a different data root')
        with operation_lock(audit):
            run_path = checked_path(audit, f'inbox/{run_id}/run.json')
            manifest = json.loads(run_path.read_bytes())
            hashes = manifest.get('input_hashes')
            if not isinstance(hashes, dict) or not hashes:
                raise HarvestError('Run lacks captured input hashes')
            if not isinstance(outcome, dict) or set(outcome) != {
                    'execution_id', 'job_id', 'status', 'reviewed_inputs', 'candidate_refs', 'missing_evidence'}:
                raise HarvestError('Explicit host-validated drafting outcome is required')
            if outcome['status'] not in ('drafted', 'no_candidates') or not isinstance(outcome['missing_evidence'], list):
                raise HarvestError('Drafting was not completed')
            if any(not manifest.get(field) or outcome[field] != manifest[field] for field in ('execution_id', 'job_id')):
                raise HarvestError('Outcome is not bound to the collected execution')
            if outcome['reviewed_inputs'] != hashes:
                raise HarvestError('Not every captured input was reviewed')
            if any(str(status).startswith(('UNREADABLE', 'not found')) for status in manifest['agents'].values()):
                raise HarvestError('Enabled reader incomplete; cursors retained and run not complete')
            required = {name for row in manifest['conversations'] for name in row['files']}
            if not required.issubset(hashes):
                raise HarvestError('Manifest omits conversation parts')
            for name, digest in hashes.items():
                if name != 'sources-index.md' and not name.startswith('conversations/'):
                    raise HarvestError('Unexpected collection artifact')
                path = checked_path(audit, f'inbox/{run_id}/{name}')
                if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
                    raise HarvestError('Collected input changed or disappeared')
            refs = outcome['candidate_refs']
            if not isinstance(refs, list) or len(set(refs)) != len(refs) or any(
                    not isinstance(ref, str) or not ref.startswith(run_id + '/') for ref in refs):
                raise HarvestError('Invalid completion candidates')
            actual = {f'{run_id}/{folder.name}' for folder in checked_path(audit, f'inbox/{run_id}/candidates').iterdir()}
            if set(refs) != actual or bool(refs) != (outcome['status'] == 'drafted'):
                raise HarvestError('Candidate completion does not match captured artifacts')
            candidate_hashes = {}
            for ref in refs:
                from wiki_candidates import load_candidate, check_format
                folder, metadata = load_candidate(audit / 'inbox', ref)
                candidate_hashes[ref] = hashlib.sha256((folder / 'candidate.json').read_bytes()).hexdigest()
                if metadata['kind'] != 'retire':
                    source = (folder / 'source.md').read_bytes()
                    if check_format(source.decode('utf-8')):
                        raise HarvestError('Incomplete or invalid drafted candidate')
                    candidate_hashes[ref + ':source'] = hashlib.sha256(source).hexdigest()
            stable = {key: value for key, value in manifest.items() if key not in ('committed', 'outcome')}
            operation_id = hashlib.sha256(canonical({'harvest': run_id, 'data_root': str(audit.resolve())})).hexdigest()
            identity = {'operation_id': operation_id, 'domain': 'harvest', 'run_id': run_id,
                        'manifest_sha256': hashlib.sha256(canonical(stable)).hexdigest()}
            store.record_operation(identity)
            result = {**outcome, 'candidate_hashes': candidate_hashes}
            store.record_step(operation_id, 'draft-completion', result)
            state_path = checked_path(audit, 'harvest-state.json')
            state = load_state(state_path)
            cursors = dict(state['cursors'])
            for agent, cursor in manifest['cursors_to_commit'].items():
                if type(cursor) not in (int, float) or not math.isfinite(cursor) or cursor < 0:
                    raise HarvestError('Invalid captured cursor')
                cursors[agent] = max(cursors.get(agent, 0), cursor)
            state.update(cursors=cursors, last_commit={'run': run_id, 'status': result['status']})
            encoded = canonical(state) + b'\n'
            if not state_path.exists() or state_path.read_bytes() != encoded:
                _atomic(state_path, encoded)
            manifest.update(committed=True, outcome=result)
            encoded = canonical(manifest) + b'\n'
            if run_path.read_bytes() != encoded:
                _atomic(run_path, encoded)
            if store.get_operation(operation_id)['state'] == 'collected':
                store.transition(operation_id, 'collected', 'drafted', result)
            return result
    except (OSError, ValueError, KeyError, TypeError, PathRefused) as exc:
        raise HarvestError('Run is incomplete or unsafe; cursors retained') from exc


def main(argv: list[str]) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--status", action="store_true")
    ap.add_argument("--commit", metavar="RUN_ID")
    ap.add_argument("--execution-id", help="Native plugin supplied occurrence, not model authority")
    ap.add_argument("--job-id", help="Native plugin supplied configured job")
    ap.add_argument("--host-outcome", action="store_true")
    ap.add_argument("--home", help="Owning native profile")
    ap.add_argument("--since", help="ISO time; test or backfill, cursors are not read")
    args = ap.parse_args(argv)

    try:
        cfg = wikiconfig.load()
        wiki = wikiconfig.project_root(cfg)
    except wikiconfig.ConfigError as exc:
        print(f"!! {exc}")
        print(json.dumps({"wakeAgent": False}))
        return 1
    audit = wikiconfig.audit_dir(cfg)
    if args.host_outcome:
        from workflow_store import WorkflowStore, WorkflowError
        from workflow_paths import checked_path
        try:
            if cfg.get('harvest_workflow_enabled') is not True:
                raise HarvestError('Native harvest completion is not explicitly activated')
            if not args.home or not cfg.get('hermes_home') or Path(args.home).resolve() != Path(cfg['hermes_home']).resolve():
                raise HarvestError('Native outcome is not owned by the selected profile')
            request = json.loads(sys.stdin.buffer.read(300001))
            if not isinstance(request, dict) or set(request) != {'run_id', 'outcome'}:
                raise HarvestError('Unsupported native outcome fields')
            outcome = request['outcome']
            if outcome.get('execution_id') != args.execution_id or outcome.get('job_id') != args.job_id:
                raise HarvestError('Native occurrence binding changed')
            with WorkflowStore(checked_path(audit, 'workflow.sqlite')) as store:
                result = finish_run(audit, request['run_id'], outcome, store)
            print(json.dumps({'ok': True, 'status': result['status']}))
            return 0
        except (HarvestError, WorkflowError, OSError, ValueError, KeyError, TypeError) as exc:
            print(json.dumps({'ok': False, 'status': 'failed', 'reason': str(exc)}))
            return 1
    hcfg = {**DEFAULTS, **(cfg.get("harvest") or {})}
    hcfg["agents"] = {**DEFAULTS["agents"], **((cfg.get("harvest") or {}).get("agents") or {})}
    state_path = audit / "harvest-state.json"
    inbox = audit / "inbox"
    state = load_state(state_path)
    roots = agent_roots(cfg)

    if args.commit:
        print('!! Agent-side commit is disabled; only a verified native host outcome may finish processing')
        print(json.dumps({'wakeAgent': False, 'status': 'refused'}))
        return 1

    now = datetime.now().timestamp()
    until = now - 60 * int(hcfg["settle_minutes"])
    first = now - 86400 * int(hcfg["first_run_days"])

    if args.status:
        for agent, on in hcfg["agents"].items():
            root = roots.get(agent)
            cur = state.get("cursors", {}).get(agent)
            print(f"{agent:11} {'on ' if on else 'off'} {'found' if root and root.exists() else 'NOT FOUND'} "
                  f"cursor={iso(cur) if cur else 'none (first run looks back ' + str(hcfg['first_run_days']) + ' days)'}")
        return 0

    if bool(args.execution_id) != bool(args.job_id):
        print(json.dumps({"wakeAgent": False, "status": "failed", "reason": "Both native binding fields are required"}))
        return 1
    run_id = datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:12]
    run_dir = inbox / run_id
    conversations, agents_report, cursors = [], {}, {}
    for agent, on in hcfg["agents"].items():
        if not on:
            agents_report[agent] = "off"
            continue
        since = ts(args.since) if args.since else float(state.get("cursors", {}).get(agent) or first)
        try:
            found = list(READERS[agent](roots[agent], since, until))
        except FileNotFoundError as exc:
            agents_report[agent] = f"not found ({exc})"
            continue
        except Exception as exc:  # a format change must be loud, never a silent skip
            agents_report[agent] = f"UNREADABLE ({exc.__class__.__name__}: {exc})"
            continue
        n = 0
        for cid, label, msgs in found:
            files, clip = render(label, msgs, int(hcfg["max_chars"]))
            if files:
                conversations.append((agent, cid, label, files, len(msgs), clip))
                n += 1
        agents_report[agent] = f"{n} conversation(s)"
        cursors[agent] = until

    failed = any(str(value).startswith(("UNREADABLE", "not found")) for value in agents_report.values())
    if not conversations and not args.execution_id:
        print("harvest: nothing new since the last run | " + " | ".join(f"{a}: {r}" for a, r in agents_report.items()))
        if any("UNREADABLE" in r for r in agents_report.values()):
            print("!! an agent's history could not be read; its format may have changed")
        failed = any(str(value).startswith(("UNREADABLE", "not found")) for value in agents_report.values())
        print(json.dumps({"wakeAgent": False, "status": "partial" if failed else "no_new_inputs"}))
        return 1 if failed else 0

    (run_dir / "conversations").mkdir(parents=True, exist_ok=False)
    (run_dir / "candidates").mkdir(exist_ok=True)
    listing = []
    for agent, cid, label, files, count, clip in conversations:
        stem = f"{agent}-{re.sub(r'[^A-Za-z0-9_-]+', '-', cid)[:60]}"
        names = [f"{stem}.md" if len(files) == 1 else f"{stem}-part{i}.md" for i in range(1, len(files) + 1)]
        for name, md in zip(names, files):
            (run_dir / "conversations" / name).write_text(md, encoding="utf-8")
        listing.append({"agent": agent, "id": cid, "label": label, "file": f"conversations/{names[0]}",
                        "files": [f"conversations/{n}" for n in names], "parts": len(names),
                        "assistant_clip": clip, "messages": count})
    (run_dir / "sources-index.md").write_text(source_index(wiki), encoding="utf-8")
    rec = {"run": run_id, "created": iso(now), "window_until": iso(until),
           "since": {a: iso(ts(args.since) if args.since else float(state.get("cursors", {}).get(a) or first))
                     for a in cursors},
           "agents": agents_report, "conversations": listing,
           "execution_id": args.execution_id, "job_id": args.job_id, "project_id": cfg.get("project_id"),
           "input_hashes": {name: hashlib.sha256((run_dir / name).read_bytes()).hexdigest()
                            for name in ["sources-index.md", *[part for row in listing for part in row["files"]]]},
           "cursors_to_commit": {} if args.since else cursors, "committed": False}
    (run_dir / "run.json").write_text(json.dumps(rec, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"harvest: run {run_id}: {len(listing)} conversation(s) | "
          + " | ".join(f"{a}: {r}" for a, r in agents_report.items()))
    for c in listing:
        if c["parts"] > 1 or c["assistant_clip"] < ASSISTANT_CLIP:
            print(f"   long: {c['label'][:60]}: {c['parts']} part(s), assistant messages cut at "
                  f"{c['assistant_clip']} chars")
    print(json.dumps({"wakeAgent": bool(conversations) and not failed, "run_id": run_id,
                      "status": "partial" if failed else "collected" if conversations else "collected_empty", "context": {"run": run_id, "run_dir": str(run_dir),
                                                     "conversations": len(listing),
                                                     "agents": agents_report}}))
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
